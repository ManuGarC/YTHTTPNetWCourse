﻿namespace ArrastrarSoltar
{
    partial class fmPapelera
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(fmPapelera));
            this.lbPapelera = new System.Windows.Forms.ListBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btSeleccion = new System.Windows.Forms.Button();
            this.btTodos = new System.Windows.Forms.Button();
            this.btVaciar = new System.Windows.Forms.Button();
            this.mncPapelera = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.vaciarPapeleraToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.restaurarTodoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.restaurarSelecciónToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panel1.SuspendLayout();
            this.mncPapelera.SuspendLayout();
            this.SuspendLayout();
            // 
            // lbPapelera
            // 
            this.lbPapelera.ContextMenuStrip = this.mncPapelera;
            this.lbPapelera.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbPapelera.FormattingEnabled = true;
            this.lbPapelera.HorizontalScrollbar = true;
            this.lbPapelera.Location = new System.Drawing.Point(0, 100);
            this.lbPapelera.Name = "lbPapelera";
            this.lbPapelera.SelectionMode = System.Windows.Forms.SelectionMode.MultiSimple;
            this.lbPapelera.Size = new System.Drawing.Size(278, 237);
            this.lbPapelera.TabIndex = 0;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.LightGray;
            this.panel1.Controls.Add(this.btSeleccion);
            this.panel1.Controls.Add(this.btTodos);
            this.panel1.Controls.Add(this.btVaciar);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.ForeColor = System.Drawing.Color.Black;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(278, 100);
            this.panel1.TabIndex = 1;
            // 
            // btSeleccion
            // 
            this.btSeleccion.Location = new System.Drawing.Point(172, 24);
            this.btSeleccion.Name = "btSeleccion";
            this.btSeleccion.Size = new System.Drawing.Size(94, 53);
            this.btSeleccion.TabIndex = 2;
            this.btSeleccion.Text = "Restaurar Elementos Seleccionados";
            this.btSeleccion.UseVisualStyleBackColor = true;
            this.btSeleccion.Click += new System.EventHandler(this.btSeleccion_Click);
            // 
            // btTodos
            // 
            this.btTodos.Location = new System.Drawing.Point(90, 24);
            this.btTodos.Name = "btTodos";
            this.btTodos.Size = new System.Drawing.Size(70, 53);
            this.btTodos.TabIndex = 1;
            this.btTodos.Text = "Restaurar Todos Elementos";
            this.btTodos.UseVisualStyleBackColor = true;
            this.btTodos.Click += new System.EventHandler(this.btTodos_Click);
            // 
            // btVaciar
            // 
            this.btVaciar.Location = new System.Drawing.Point(12, 24);
            this.btVaciar.Name = "btVaciar";
            this.btVaciar.Size = new System.Drawing.Size(66, 53);
            this.btVaciar.TabIndex = 0;
            this.btVaciar.Text = "Vaciar Papelera";
            this.btVaciar.UseVisualStyleBackColor = true;
            this.btVaciar.Click += new System.EventHandler(this.btVaciar_Click);
            // 
            // mncPapelera
            // 
            this.mncPapelera.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.vaciarPapeleraToolStripMenuItem,
            this.restaurarTodoToolStripMenuItem,
            this.restaurarSelecciónToolStripMenuItem});
            this.mncPapelera.Name = "mncPapelera";
            this.mncPapelera.Size = new System.Drawing.Size(181, 92);
            // 
            // vaciarPapeleraToolStripMenuItem
            // 
            this.vaciarPapeleraToolStripMenuItem.Name = "vaciarPapeleraToolStripMenuItem";
            this.vaciarPapeleraToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.vaciarPapeleraToolStripMenuItem.Text = "Vaciar Papelera";
            this.vaciarPapeleraToolStripMenuItem.Click += new System.EventHandler(this.btVaciar_Click);
            // 
            // restaurarTodoToolStripMenuItem
            // 
            this.restaurarTodoToolStripMenuItem.Name = "restaurarTodoToolStripMenuItem";
            this.restaurarTodoToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.restaurarTodoToolStripMenuItem.Text = "Restaurar Todo";
            this.restaurarTodoToolStripMenuItem.Click += new System.EventHandler(this.btTodos_Click);
            // 
            // restaurarSelecciónToolStripMenuItem
            // 
            this.restaurarSelecciónToolStripMenuItem.Name = "restaurarSelecciónToolStripMenuItem";
            this.restaurarSelecciónToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.restaurarSelecciónToolStripMenuItem.Text = "Restaurar Selección";
            this.restaurarSelecciónToolStripMenuItem.Click += new System.EventHandler(this.btSeleccion_Click);
            // 
            // fmPapelera
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(278, 337);
            this.Controls.Add(this.lbPapelera);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "fmPapelera";
            this.Text = "Papelera de Reciclaje";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.fmPapelera_FormClosing);
            this.panel1.ResumeLayout(false);
            this.mncPapelera.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        public System.Windows.Forms.ListBox lbPapelera;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btSeleccion;
        private System.Windows.Forms.Button btTodos;
        private System.Windows.Forms.Button btVaciar;
        private System.Windows.Forms.ContextMenuStrip mncPapelera;
        private System.Windows.Forms.ToolStripMenuItem vaciarPapeleraToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem restaurarTodoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem restaurarSelecciónToolStripMenuItem;
    }
}