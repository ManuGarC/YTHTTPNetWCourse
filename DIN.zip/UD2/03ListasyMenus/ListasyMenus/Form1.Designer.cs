﻿namespace ListasyMenus
{
    partial class fmListasMenus
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.cbCursos = new System.Windows.Forms.ComboBox();
            this.lbAlumnos = new System.Windows.Forms.ListBox();
            this.cnAlumno = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.nuevoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.abrirToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.guardarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tbAlumno = new System.Windows.Forms.TextBox();
            this.laNuevo = new System.Windows.Forms.Label();
            this.btMostrarTodos = new System.Windows.Forms.Button();
            this.btMostrar = new System.Windows.Forms.Button();
            this.mnListas = new System.Windows.Forms.MenuStrip();
            this.itArchivo = new System.Windows.Forms.ToolStripMenuItem();
            this.itNuevo = new System.Windows.Forms.ToolStripMenuItem();
            this.itAbrir = new System.Windows.Forms.ToolStripMenuItem();
            this.itGuardar = new System.Windows.Forms.ToolStripMenuItem();
            this.itSalir = new System.Windows.Forms.ToolStripMenuItem();
            this.itAyuda = new System.Windows.Forms.ToolStripMenuItem();
            this.itAcercaDe = new System.Windows.Forms.ToolStripMenuItem();
            this.ckOrdenar = new System.Windows.Forms.CheckBox();
            this.ckActualizar = new System.Windows.Forms.CheckBox();
            this.pnActualiza = new System.Windows.Forms.Panel();
            this.btBuscar = new System.Windows.Forms.Button();
            this.btInsertar = new System.Windows.Forms.Button();
            this.btBorrar = new System.Windows.Forms.Button();
            this.btAnyadir = new System.Windows.Forms.Button();
            this.btAbajo = new System.Windows.Forms.Button();
            this.btArriba = new System.Windows.Forms.Button();
            this.cnAlumno.SuspendLayout();
            this.mnListas.SuspendLayout();
            this.pnActualiza.SuspendLayout();
            this.SuspendLayout();
            // 
            // cbCursos
            // 
            this.cbCursos.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbCursos.FormattingEnabled = true;
            this.cbCursos.Items.AddRange(new object[] {
            "1A",
            "1B",
            "2A",
            "2B",
            "3A",
            "3B",
            "4A",
            "4B"});
            this.cbCursos.Location = new System.Drawing.Point(76, 58);
            this.cbCursos.Name = "cbCursos";
            this.cbCursos.Size = new System.Drawing.Size(121, 21);
            this.cbCursos.TabIndex = 0;
            this.cbCursos.TextChanged += new System.EventHandler(this.cbCursos_TextChanged);
            // 
            // lbAlumnos
            // 
            this.lbAlumnos.ContextMenuStrip = this.cnAlumno;
            this.lbAlumnos.FormattingEnabled = true;
            this.lbAlumnos.Location = new System.Drawing.Point(76, 117);
            this.lbAlumnos.Name = "lbAlumnos";
            this.lbAlumnos.Size = new System.Drawing.Size(140, 199);
            this.lbAlumnos.TabIndex = 1;
            // 
            // cnAlumno
            // 
            this.cnAlumno.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.nuevoToolStripMenuItem,
            this.abrirToolStripMenuItem,
            this.guardarToolStripMenuItem});
            this.cnAlumno.Name = "cnAlumno";
            this.cnAlumno.Size = new System.Drawing.Size(117, 70);
            // 
            // nuevoToolStripMenuItem
            // 
            this.nuevoToolStripMenuItem.Name = "nuevoToolStripMenuItem";
            this.nuevoToolStripMenuItem.Size = new System.Drawing.Size(116, 22);
            this.nuevoToolStripMenuItem.Text = "Nuevo";
            this.nuevoToolStripMenuItem.Click += new System.EventHandler(this.itNuevo_Click);
            // 
            // abrirToolStripMenuItem
            // 
            this.abrirToolStripMenuItem.Name = "abrirToolStripMenuItem";
            this.abrirToolStripMenuItem.Size = new System.Drawing.Size(116, 22);
            this.abrirToolStripMenuItem.Text = "Abrir";
            this.abrirToolStripMenuItem.Click += new System.EventHandler(this.itAbrir_Click);
            // 
            // guardarToolStripMenuItem
            // 
            this.guardarToolStripMenuItem.Name = "guardarToolStripMenuItem";
            this.guardarToolStripMenuItem.Size = new System.Drawing.Size(116, 22);
            this.guardarToolStripMenuItem.Text = "Guardar";
            this.guardarToolStripMenuItem.Click += new System.EventHandler(this.itGuardar_Click);
            // 
            // tbAlumno
            // 
            this.tbAlumno.Enabled = false;
            this.tbAlumno.Location = new System.Drawing.Point(76, 374);
            this.tbAlumno.Name = "tbAlumno";
            this.tbAlumno.Size = new System.Drawing.Size(100, 20);
            this.tbAlumno.TabIndex = 2;
            this.tbAlumno.TextChanged += new System.EventHandler(this.tbAlumno_TextChanged);
            this.tbAlumno.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbAlumno_KeyPress);
            // 
            // laNuevo
            // 
            this.laNuevo.AutoSize = true;
            this.laNuevo.Location = new System.Drawing.Point(73, 358);
            this.laNuevo.Name = "laNuevo";
            this.laNuevo.Size = new System.Drawing.Size(39, 13);
            this.laNuevo.TabIndex = 3;
            this.laNuevo.Text = "Nuevo";
            // 
            // btMostrarTodos
            // 
            this.btMostrarTodos.AutoSize = true;
            this.btMostrarTodos.Location = new System.Drawing.Point(251, 293);
            this.btMostrarTodos.Name = "btMostrarTodos";
            this.btMostrarTodos.Size = new System.Drawing.Size(85, 23);
            this.btMostrarTodos.TabIndex = 4;
            this.btMostrarTodos.Text = "Mostrar Todos";
            this.btMostrarTodos.UseVisualStyleBackColor = true;
            this.btMostrarTodos.Click += new System.EventHandler(this.btMostrarTodos_Click);
            // 
            // btMostrar
            // 
            this.btMostrar.AutoSize = true;
            this.btMostrar.Location = new System.Drawing.Point(360, 293);
            this.btMostrar.Name = "btMostrar";
            this.btMostrar.Size = new System.Drawing.Size(84, 23);
            this.btMostrar.TabIndex = 5;
            this.btMostrar.Text = "Mostrar Mas...";
            this.btMostrar.UseVisualStyleBackColor = true;
            this.btMostrar.Click += new System.EventHandler(this.btMostrar_Click);
            // 
            // mnListas
            // 
            this.mnListas.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.itArchivo,
            this.itAyuda});
            this.mnListas.Location = new System.Drawing.Point(0, 0);
            this.mnListas.Name = "mnListas";
            this.mnListas.Size = new System.Drawing.Size(800, 24);
            this.mnListas.TabIndex = 6;
            this.mnListas.Text = "menuStrip1";
            // 
            // itArchivo
            // 
            this.itArchivo.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.itNuevo,
            this.itAbrir,
            this.itGuardar,
            this.itSalir});
            this.itArchivo.Name = "itArchivo";
            this.itArchivo.Size = new System.Drawing.Size(60, 20);
            this.itArchivo.Text = "Archivo";
            // 
            // itNuevo
            // 
            this.itNuevo.Image = global::ListasyMenus.Properties.Resources.NUEVO;
            this.itNuevo.Name = "itNuevo";
            this.itNuevo.ShortcutKeyDisplayString = "Ctrl+N";
            this.itNuevo.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.N)));
            this.itNuevo.Size = new System.Drawing.Size(158, 22);
            this.itNuevo.Text = "&Nuevo";
            this.itNuevo.Click += new System.EventHandler(this.itNuevo_Click);
            // 
            // itAbrir
            // 
            this.itAbrir.Image = global::ListasyMenus.Properties.Resources.ABRIR;
            this.itAbrir.Name = "itAbrir";
            this.itAbrir.Size = new System.Drawing.Size(158, 22);
            this.itAbrir.Text = "Abrir";
            this.itAbrir.Click += new System.EventHandler(this.itAbrir_Click);
            // 
            // itGuardar
            // 
            this.itGuardar.Image = global::ListasyMenus.Properties.Resources.GRABAR;
            this.itGuardar.Name = "itGuardar";
            this.itGuardar.ShortcutKeyDisplayString = "Ctrl+G";
            this.itGuardar.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.G)));
            this.itGuardar.Size = new System.Drawing.Size(158, 22);
            this.itGuardar.Text = "Guardar";
            this.itGuardar.Click += new System.EventHandler(this.itGuardar_Click);
            // 
            // itSalir
            // 
            this.itSalir.Name = "itSalir";
            this.itSalir.ShortcutKeyDisplayString = "Alt+X";
            this.itSalir.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.X)));
            this.itSalir.Size = new System.Drawing.Size(158, 22);
            this.itSalir.Text = "Salir";
            this.itSalir.Click += new System.EventHandler(this.itSalir_Click);
            // 
            // itAyuda
            // 
            this.itAyuda.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.itAcercaDe});
            this.itAyuda.Name = "itAyuda";
            this.itAyuda.Size = new System.Drawing.Size(53, 20);
            this.itAyuda.Text = "Ayuda";
            // 
            // itAcercaDe
            // 
            this.itAcercaDe.Name = "itAcercaDe";
            this.itAcercaDe.Size = new System.Drawing.Size(135, 22);
            this.itAcercaDe.Text = "Acerca de...";
            this.itAcercaDe.Click += new System.EventHandler(this.itAcercaDe_Click);
            // 
            // ckOrdenar
            // 
            this.ckOrdenar.AutoSize = true;
            this.ckOrdenar.Location = new System.Drawing.Point(315, 205);
            this.ckOrdenar.Name = "ckOrdenar";
            this.ckOrdenar.Size = new System.Drawing.Size(129, 17);
            this.ckOrdenar.TabIndex = 7;
            this.ckOrdenar.Text = "Ordena Lista Alumnos";
            this.ckOrdenar.UseVisualStyleBackColor = true;
            this.ckOrdenar.CheckedChanged += new System.EventHandler(this.ckOrdenar_CheckedChanged);
            // 
            // ckActualizar
            // 
            this.ckActualizar.AutoSize = true;
            this.ckActualizar.BackColor = System.Drawing.Color.Red;
            this.ckActualizar.Location = new System.Drawing.Point(613, 297);
            this.ckActualizar.Name = "ckActualizar";
            this.ckActualizar.Size = new System.Drawing.Size(72, 17);
            this.ckActualizar.TabIndex = 8;
            this.ckActualizar.Text = "Actualizar";
            this.ckActualizar.UseVisualStyleBackColor = false;
            this.ckActualizar.CheckedChanged += new System.EventHandler(this.ckActualizar_CheckedChanged);
            // 
            // pnActualiza
            // 
            this.pnActualiza.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnActualiza.Controls.Add(this.btBuscar);
            this.pnActualiza.Controls.Add(this.btInsertar);
            this.pnActualiza.Controls.Add(this.btBorrar);
            this.pnActualiza.Controls.Add(this.btAnyadir);
            this.pnActualiza.Location = new System.Drawing.Point(581, 81);
            this.pnActualiza.Name = "pnActualiza";
            this.pnActualiza.Size = new System.Drawing.Size(135, 194);
            this.pnActualiza.TabIndex = 12;
            this.pnActualiza.Visible = false;
            // 
            // btBuscar
            // 
            this.btBuscar.Location = new System.Drawing.Point(30, 148);
            this.btBuscar.Name = "btBuscar";
            this.btBuscar.Size = new System.Drawing.Size(75, 23);
            this.btBuscar.TabIndex = 3;
            this.btBuscar.Text = "Buscar";
            this.btBuscar.UseVisualStyleBackColor = true;
            this.btBuscar.Click += new System.EventHandler(this.btBuscar_Click);
            // 
            // btInsertar
            // 
            this.btInsertar.Location = new System.Drawing.Point(30, 107);
            this.btInsertar.Name = "btInsertar";
            this.btInsertar.Size = new System.Drawing.Size(75, 23);
            this.btInsertar.TabIndex = 2;
            this.btInsertar.Text = "Insertar";
            this.btInsertar.UseVisualStyleBackColor = true;
            this.btInsertar.Click += new System.EventHandler(this.btInsertar_Click);
            // 
            // btBorrar
            // 
            this.btBorrar.Location = new System.Drawing.Point(30, 66);
            this.btBorrar.Name = "btBorrar";
            this.btBorrar.Size = new System.Drawing.Size(75, 23);
            this.btBorrar.TabIndex = 1;
            this.btBorrar.Text = "Borrar";
            this.btBorrar.UseVisualStyleBackColor = true;
            this.btBorrar.Click += new System.EventHandler(this.btBorrar_Click);
            // 
            // btAnyadir
            // 
            this.btAnyadir.Location = new System.Drawing.Point(30, 25);
            this.btAnyadir.Name = "btAnyadir";
            this.btAnyadir.Size = new System.Drawing.Size(75, 23);
            this.btAnyadir.TabIndex = 0;
            this.btAnyadir.Text = "Añadir";
            this.btAnyadir.UseVisualStyleBackColor = true;
            this.btAnyadir.Click += new System.EventHandler(this.btAnyadir_Click);
            // 
            // btAbajo
            // 
            this.btAbajo.Image = global::ListasyMenus.Properties.Resources.flechaB;
            this.btAbajo.Location = new System.Drawing.Point(251, 228);
            this.btAbajo.Name = "btAbajo";
            this.btAbajo.Size = new System.Drawing.Size(44, 47);
            this.btAbajo.TabIndex = 10;
            this.btAbajo.UseVisualStyleBackColor = true;
            this.btAbajo.Click += new System.EventHandler(this.btAbajo_Click);
            // 
            // btArriba
            // 
            this.btArriba.Image = global::ListasyMenus.Properties.Resources.flechaA;
            this.btArriba.Location = new System.Drawing.Point(251, 152);
            this.btArriba.Name = "btArriba";
            this.btArriba.Size = new System.Drawing.Size(44, 47);
            this.btArriba.TabIndex = 9;
            this.btArriba.UseVisualStyleBackColor = true;
            this.btArriba.Click += new System.EventHandler(this.btArriba_Click);
            // 
            // fmListasMenus
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.pnActualiza);
            this.Controls.Add(this.btAbajo);
            this.Controls.Add(this.btArriba);
            this.Controls.Add(this.ckActualizar);
            this.Controls.Add(this.ckOrdenar);
            this.Controls.Add(this.btMostrar);
            this.Controls.Add(this.btMostrarTodos);
            this.Controls.Add(this.laNuevo);
            this.Controls.Add(this.tbAlumno);
            this.Controls.Add(this.lbAlumnos);
            this.Controls.Add(this.cbCursos);
            this.Controls.Add(this.mnListas);
            this.MainMenuStrip = this.mnListas;
            this.Name = "fmListasMenus";
            this.Text = "Listas y Menus";
            this.Load += new System.EventHandler(this.fmListasMenus_Load);
            this.cnAlumno.ResumeLayout(false);
            this.mnListas.ResumeLayout(false);
            this.mnListas.PerformLayout();
            this.pnActualiza.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cbCursos;
        private System.Windows.Forms.ListBox lbAlumnos;
        private System.Windows.Forms.TextBox tbAlumno;
        private System.Windows.Forms.Label laNuevo;
        private System.Windows.Forms.Button btMostrarTodos;
        private System.Windows.Forms.Button btMostrar;
        private System.Windows.Forms.MenuStrip mnListas;
        private System.Windows.Forms.ToolStripMenuItem itArchivo;
        private System.Windows.Forms.ToolStripMenuItem itAyuda;
        private System.Windows.Forms.ToolStripMenuItem itNuevo;
        private System.Windows.Forms.ToolStripMenuItem itAbrir;
        private System.Windows.Forms.ToolStripMenuItem itGuardar;
        private System.Windows.Forms.ToolStripMenuItem itAcercaDe;
        private System.Windows.Forms.ToolStripMenuItem itSalir;
        private System.Windows.Forms.CheckBox ckOrdenar;
        private System.Windows.Forms.CheckBox ckActualizar;
        private System.Windows.Forms.Button btArriba;
        private System.Windows.Forms.Button btAbajo;
        private System.Windows.Forms.ContextMenuStrip cnAlumno;
        private System.Windows.Forms.ToolStripMenuItem nuevoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem abrirToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem guardarToolStripMenuItem;
        private System.Windows.Forms.Panel pnActualiza;
        private System.Windows.Forms.Button btBuscar;
        private System.Windows.Forms.Button btInsertar;
        private System.Windows.Forms.Button btBorrar;
        private System.Windows.Forms.Button btAnyadir;
    }
}

