﻿namespace ElFormulario
{
    partial class fmFormulario
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(fmFormulario));
            this.laBienvenido = new System.Windows.Forms.Label();
            this.btArriba = new System.Windows.Forms.Button();
            this.btAbajo = new System.Windows.Forms.Button();
            this.btIzquierda = new System.Windows.Forms.Button();
            this.btDerecha = new System.Windows.Forms.Button();
            this.laMover = new System.Windows.Forms.Label();
            this.laTamanyo = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btTres = new System.Windows.Forms.Button();
            this.btDos = new System.Windows.Forms.Button();
            this.btUno = new System.Windows.Forms.Button();
            this.pnBotones = new System.Windows.Forms.Panel();
            this.btAcercaDe = new System.Windows.Forms.Button();
            this.btSalir = new System.Windows.Forms.Button();
            this.btPanel = new System.Windows.Forms.Button();
            this.btControles = new System.Windows.Forms.Button();
            this.btDetras = new System.Windows.Forms.Button();
            this.btDelante = new System.Windows.Forms.Button();
            this.btDisminuye = new System.Windows.Forms.Button();
            this.btAumenta = new System.Windows.Forms.Button();
            this.btVisible = new System.Windows.Forms.Button();
            this.btCreaBoton = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.pnBotones.SuspendLayout();
            this.SuspendLayout();
            // 
            // laBienvenido
            // 
            this.laBienvenido.BackColor = System.Drawing.Color.LightGray;
            this.laBienvenido.Cursor = System.Windows.Forms.Cursors.No;
            this.laBienvenido.Dock = System.Windows.Forms.DockStyle.Top;
            this.laBienvenido.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.laBienvenido.ForeColor = System.Drawing.SystemColors.Highlight;
            this.laBienvenido.Image = ((System.Drawing.Image)(resources.GetObject("laBienvenido.Image")));
            this.laBienvenido.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.laBienvenido.Location = new System.Drawing.Point(0, 0);
            this.laBienvenido.Name = "laBienvenido";
            this.laBienvenido.Size = new System.Drawing.Size(872, 34);
            this.laBienvenido.TabIndex = 0;
            this.laBienvenido.Text = "Bienvenido a la Aplicación";
            this.laBienvenido.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btArriba
            // 
            this.btArriba.AutoSize = true;
            this.btArriba.Location = new System.Drawing.Point(133, 126);
            this.btArriba.Name = "btArriba";
            this.btArriba.Size = new System.Drawing.Size(75, 30);
            this.btArriba.TabIndex = 1;
            this.btArriba.Text = "Arriba";
            this.btArriba.UseVisualStyleBackColor = true;
            this.btArriba.Click += new System.EventHandler(this.btArriba_Click);
            // 
            // btAbajo
            // 
            this.btAbajo.AutoSize = true;
            this.btAbajo.Location = new System.Drawing.Point(133, 255);
            this.btAbajo.Name = "btAbajo";
            this.btAbajo.Size = new System.Drawing.Size(75, 30);
            this.btAbajo.TabIndex = 2;
            this.btAbajo.Text = "Abajo";
            this.btAbajo.UseVisualStyleBackColor = true;
            this.btAbajo.Click += new System.EventHandler(this.btAbajo_Click);
            // 
            // btIzquierda
            // 
            this.btIzquierda.AutoSize = true;
            this.btIzquierda.Location = new System.Drawing.Point(38, 183);
            this.btIzquierda.Name = "btIzquierda";
            this.btIzquierda.Size = new System.Drawing.Size(85, 30);
            this.btIzquierda.TabIndex = 3;
            this.btIzquierda.Text = "Izquierda";
            this.btIzquierda.UseVisualStyleBackColor = true;
            this.btIzquierda.Click += new System.EventHandler(this.btIzquierda_Click);
            // 
            // btDerecha
            // 
            this.btDerecha.AutoSize = true;
            this.btDerecha.Location = new System.Drawing.Point(214, 183);
            this.btDerecha.Name = "btDerecha";
            this.btDerecha.Size = new System.Drawing.Size(80, 30);
            this.btDerecha.TabIndex = 4;
            this.btDerecha.Text = "Derecha";
            this.btDerecha.UseVisualStyleBackColor = true;
            this.btDerecha.Click += new System.EventHandler(this.btDerecha_Click);
            // 
            // laMover
            // 
            this.laMover.AutoSize = true;
            this.laMover.BackColor = System.Drawing.SystemColors.HotTrack;
            this.laMover.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.laMover.ForeColor = System.Drawing.Color.Red;
            this.laMover.Location = new System.Drawing.Point(387, 130);
            this.laMover.Name = "laMover";
            this.laMover.Size = new System.Drawing.Size(87, 26);
            this.laMover.TabIndex = 5;
            this.laMover.Text = "XXXXX";
            // 
            // laTamanyo
            // 
            this.laTamanyo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.laTamanyo.AutoSize = true;
            this.laTamanyo.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.laTamanyo.ForeColor = System.Drawing.Color.Red;
            this.laTamanyo.Location = new System.Drawing.Point(33, 357);
            this.laTamanyo.Name = "laTamanyo";
            this.laTamanyo.Size = new System.Drawing.Size(36, 26);
            this.laTamanyo.TabIndex = 6;
            this.laTamanyo.Text = "16";
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.groupBox1.Controls.Add(this.btTres);
            this.groupBox1.Controls.Add(this.btDos);
            this.groupBox1.Controls.Add(this.btUno);
            this.groupBox1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.groupBox1.Location = new System.Drawing.Point(599, 151);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(224, 100);
            this.groupBox1.TabIndex = 7;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Prueba de Sender";
            // 
            // btTres
            // 
            this.btTres.AutoSize = true;
            this.btTres.Location = new System.Drawing.Point(157, 38);
            this.btTres.Name = "btTres";
            this.btTres.Size = new System.Drawing.Size(50, 30);
            this.btTres.TabIndex = 2;
            this.btTres.Text = "Tres";
            this.btTres.UseVisualStyleBackColor = true;
            this.btTres.Click += new System.EventHandler(this.btUno_Click);
            // 
            // btDos
            // 
            this.btDos.AutoSize = true;
            this.btDos.Location = new System.Drawing.Point(87, 38);
            this.btDos.Name = "btDos";
            this.btDos.Size = new System.Drawing.Size(50, 30);
            this.btDos.TabIndex = 1;
            this.btDos.Text = "Dos";
            this.btDos.UseVisualStyleBackColor = true;
            this.btDos.Click += new System.EventHandler(this.btUno_Click);
            // 
            // btUno
            // 
            this.btUno.AutoSize = true;
            this.btUno.Location = new System.Drawing.Point(17, 38);
            this.btUno.Name = "btUno";
            this.btUno.Size = new System.Drawing.Size(50, 30);
            this.btUno.TabIndex = 0;
            this.btUno.Text = "Uno";
            this.btUno.UseVisualStyleBackColor = true;
            this.btUno.Click += new System.EventHandler(this.btUno_Click);
            // 
            // pnBotones
            // 
            this.pnBotones.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnBotones.Controls.Add(this.btAcercaDe);
            this.pnBotones.Controls.Add(this.btSalir);
            this.pnBotones.Controls.Add(this.btPanel);
            this.pnBotones.Controls.Add(this.btControles);
            this.pnBotones.Controls.Add(this.btDetras);
            this.pnBotones.Controls.Add(this.btDelante);
            this.pnBotones.Controls.Add(this.btDisminuye);
            this.pnBotones.Controls.Add(this.btAumenta);
            this.pnBotones.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pnBotones.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnBotones.Location = new System.Drawing.Point(0, 392);
            this.pnBotones.Name = "pnBotones";
            this.pnBotones.Size = new System.Drawing.Size(872, 49);
            this.pnBotones.TabIndex = 8;
            // 
            // btAcercaDe
            // 
            this.btAcercaDe.AutoSize = true;
            this.btAcercaDe.Location = new System.Drawing.Point(767, 4);
            this.btAcercaDe.Name = "btAcercaDe";
            this.btAcercaDe.Size = new System.Drawing.Size(91, 30);
            this.btAcercaDe.TabIndex = 7;
            this.btAcercaDe.Text = "Acerca de";
            this.btAcercaDe.UseVisualStyleBackColor = true;
            this.btAcercaDe.Click += new System.EventHandler(this.btAcercaDe_Click);
            // 
            // btSalir
            // 
            this.btSalir.AutoSize = true;
            this.btSalir.Location = new System.Drawing.Point(659, 4);
            this.btSalir.Name = "btSalir";
            this.btSalir.Size = new System.Drawing.Size(75, 30);
            this.btSalir.TabIndex = 6;
            this.btSalir.Text = "Salir";
            this.btSalir.UseVisualStyleBackColor = true;
            this.btSalir.Click += new System.EventHandler(this.btSalir_Click);
            // 
            // btPanel
            // 
            this.btPanel.AutoSize = true;
            this.btPanel.Location = new System.Drawing.Point(494, 5);
            this.btPanel.Name = "btPanel";
            this.btPanel.Size = new System.Drawing.Size(131, 30);
            this.btPanel.TabIndex = 5;
            this.btPanel.Text = "Controles Panel";
            this.btPanel.UseVisualStyleBackColor = true;
            this.btPanel.Click += new System.EventHandler(this.btPanel_Click);
            // 
            // btControles
            // 
            this.btControles.AutoSize = true;
            this.btControles.Location = new System.Drawing.Point(360, 5);
            this.btControles.Name = "btControles";
            this.btControles.Size = new System.Drawing.Size(128, 30);
            this.btControles.TabIndex = 4;
            this.btControles.Text = "Controles Form";
            this.btControles.UseVisualStyleBackColor = true;
            this.btControles.Click += new System.EventHandler(this.btControles_Click);
            // 
            // btDetras
            // 
            this.btDetras.AutoSize = true;
            this.btDetras.Location = new System.Drawing.Point(279, 5);
            this.btDetras.Name = "btDetras";
            this.btDetras.Size = new System.Drawing.Size(75, 30);
            this.btDetras.TabIndex = 3;
            this.btDetras.Text = "Detrás";
            this.btDetras.UseVisualStyleBackColor = true;
            this.btDetras.Click += new System.EventHandler(this.btDetras_Click);
            // 
            // btDelante
            // 
            this.btDelante.AutoSize = true;
            this.btDelante.Location = new System.Drawing.Point(198, 5);
            this.btDelante.Name = "btDelante";
            this.btDelante.Size = new System.Drawing.Size(75, 30);
            this.btDelante.TabIndex = 2;
            this.btDelante.Text = "Delante";
            this.btDelante.UseVisualStyleBackColor = true;
            this.btDelante.Click += new System.EventHandler(this.btDelante_Click);
            // 
            // btDisminuye
            // 
            this.btDisminuye.AutoSize = true;
            this.btDisminuye.Location = new System.Drawing.Point(100, 5);
            this.btDisminuye.Name = "btDisminuye";
            this.btDisminuye.Size = new System.Drawing.Size(92, 30);
            this.btDisminuye.TabIndex = 1;
            this.btDisminuye.Text = "Disminuye";
            this.btDisminuye.UseVisualStyleBackColor = true;
            this.btDisminuye.Click += new System.EventHandler(this.btDisminuye_Click);
            // 
            // btAumenta
            // 
            this.btAumenta.AutoSize = true;
            this.btAumenta.Location = new System.Drawing.Point(10, 5);
            this.btAumenta.Name = "btAumenta";
            this.btAumenta.Size = new System.Drawing.Size(84, 30);
            this.btAumenta.TabIndex = 0;
            this.btAumenta.Text = "Aumenta";
            this.btAumenta.UseVisualStyleBackColor = true;
            this.btAumenta.Click += new System.EventHandler(this.btAumenta_Click);
            // 
            // btVisible
            // 
            this.btVisible.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btVisible.AutoSize = true;
            this.btVisible.Location = new System.Drawing.Point(756, 356);
            this.btVisible.Name = "btVisible";
            this.btVisible.Size = new System.Drawing.Size(75, 30);
            this.btVisible.TabIndex = 9;
            this.btVisible.Text = "button1";
            this.btVisible.UseVisualStyleBackColor = true;
            this.btVisible.Click += new System.EventHandler(this.btVisible_Click);
            // 
            // btCreaBoton
            // 
            this.btCreaBoton.AutoSize = true;
            this.btCreaBoton.Location = new System.Drawing.Point(398, 261);
            this.btCreaBoton.Name = "btCreaBoton";
            this.btCreaBoton.Size = new System.Drawing.Size(100, 30);
            this.btCreaBoton.TabIndex = 10;
            this.btCreaBoton.Text = "Crea Botón";
            this.btCreaBoton.UseVisualStyleBackColor = true;
            this.btCreaBoton.Click += new System.EventHandler(this.btCreaBoton_Click);
            // 
            // fmFormulario
            // 
            this.AccessibleName = "";
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.PaleTurquoise;
            this.ClientSize = new System.Drawing.Size(872, 441);
            this.Controls.Add(this.btCreaBoton);
            this.Controls.Add(this.btVisible);
            this.Controls.Add(this.pnBotones);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.laTamanyo);
            this.Controls.Add(this.laMover);
            this.Controls.Add(this.btDerecha);
            this.Controls.Add(this.btIzquierda);
            this.Controls.Add(this.btAbajo);
            this.Controls.Add(this.btArriba);
            this.Controls.Add(this.laBienvenido);
            this.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "fmFormulario";
            this.Text = "El Formulario";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.fmFormulario_FormClosed);
            this.Load += new System.EventHandler(this.fmFormulario_Load);
            this.Click += new System.EventHandler(this.fmFormulario_Click);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.pnBotones.ResumeLayout(false);
            this.pnBotones.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label laBienvenido;
        private System.Windows.Forms.Button btArriba;
        private System.Windows.Forms.Button btAbajo;
        private System.Windows.Forms.Button btIzquierda;
        private System.Windows.Forms.Button btDerecha;
        private System.Windows.Forms.Label laMover;
        private System.Windows.Forms.Label laTamanyo;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btDos;
        private System.Windows.Forms.Button btUno;
        private System.Windows.Forms.Button btTres;
        private System.Windows.Forms.Panel pnBotones;
        private System.Windows.Forms.Button btAcercaDe;
        private System.Windows.Forms.Button btSalir;
        private System.Windows.Forms.Button btPanel;
        private System.Windows.Forms.Button btControles;
        private System.Windows.Forms.Button btDetras;
        private System.Windows.Forms.Button btDelante;
        private System.Windows.Forms.Button btDisminuye;
        private System.Windows.Forms.Button btAumenta;
        private System.Windows.Forms.Button btVisible;
        private System.Windows.Forms.Button btCreaBoton;
    }
}

