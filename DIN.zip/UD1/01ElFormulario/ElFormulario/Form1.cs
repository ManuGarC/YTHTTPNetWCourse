﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.LinkLabel;

namespace ElFormulario
{
    public partial class fmFormulario : Form
    {
        public fmFormulario()
        {
            InitializeComponent();
        }

        private void fmFormulario_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Hola Mundo");
        }

        private void btArriba_Click(object sender, EventArgs e)
        {
            if (laMover.Top <= -laMover.Height) //comprobamos si se sale por arriba
{
                laMover.Top = Height - 44; //Para que aparezca por abajo
            }
            laMover.Top = laMover.Top - 8; //Movimiento de 8 pixeles cada vez
        }

        private void btDerecha_Click(object sender, EventArgs e)
        {
            if (laMover.Left >= Width) //comprobamos si se sale por la derecha
            {
                laMover.Left = -laMover.Width; //Para que aparezca por la izquierda
            }
            laMover.Left = laMover.Left + 8;
        }

        private void btAbajo_Click(object sender, EventArgs e)
        {
            if (laMover.Top >= Height) //comprobamos si se sale por abajo
            {
                laMover.Top = -laMover.Height; //Para que aparezca por arriba
            }
            laMover.Top = laMover.Top + 8; //Movimiento de 8 pixeles cada vez
        }

        private void btIzquierda_Click(object sender, EventArgs e)
        {
            if (laMover.Left <= -laMover.Width) //comprobamos si se sale por la izquierda
            {
                laMover.Left = Width - 44; //Para que aparezca por la derecha
            }
            laMover.Left = laMover.Left - 8;
        }

        private void btVisible_Click(object sender, EventArgs e)
        {
            pnBotones.Visible = !pnBotones.Visible;

            if (pnBotones.Visible)
            {
                btVisible.Text = "Pon No Visible";
                btVisible.ForeColor = Color.Green;
            }
            else
            {
                btVisible.Text = "Pon Visible";
                btVisible.ForeColor = Color.Red;
            }
        }

        private void fmFormulario_Load(object sender, EventArgs e)
        {
            btVisible.Text = "Pon no Visible";
            btVisible.ForeColor = Color.Green;
        }

        private void fmFormulario_FormClosed(object sender, FormClosedEventArgs e)
        {
            MessageBox.Show("Nos vemos!");
        }

        private void btAumenta_Click(object sender, EventArgs e)
        {
            float fAumenta = laMover.Font.Size; // Variable para asignar nuevo tamaño
            fAumenta++;

            if (fAumenta <= 100) // Tamaño máximo permitido
            {
                laTamanyo.Text = Convert.ToString(fAumenta);//Asignamos valor al label que indica el tamaño(parte central inferior izquierda)
                btAumenta.Text = "Suma: " + Convert.ToString(fAumenta);//Asignamos también nuevo valor a los text
                btDisminuye.Text = "Resta: " + Convert.ToString(fAumenta);//de los botones que realizan acción al hacer click
                laMover.Font = new Font("", fAumenta, FontStyle.Regular,
                GraphicsUnit.Point);//Código que asigna nuevo tamaño a la fuente del label.
            }
        }

        private void btDisminuye_Click(object sender, EventArgs e)
        {
            float fDisminuye = laMover.Font.Size;
            fDisminuye--;

            if (fDisminuye >= 8) //Minimo una Font size de 8.
            {
                laTamanyo.Text = Convert.ToString(fDisminuye);
                btDisminuye.Text = "Resta: " + Convert.ToString(fDisminuye);
                btAumenta.Text = "Suma: " + Convert.ToString(fDisminuye);
                laMover.Font = new Font("", fDisminuye, FontStyle.Regular,
                GraphicsUnit.Point);
            }
        }

        private void btDelante_Click(object sender, EventArgs e)
        {
            laMover.BringToFront(); //método que envía a primer plano.
        }

        private void btDetras_Click(object sender, EventArgs e)
        {
            laMover.SendToBack();//método que envía al fondo al objeto
        }

        private void btControles_Click(object sender, EventArgs e)
        {
            foreach (Control micontrol in Controls)
            {
                if (micontrol is Button) // usamos el operador de clase is
                {
                    micontrol.ForeColor = Color.Red;
                }
                MessageBox.Show(micontrol.Name);
            }
            
            MessageBox.Show("Total Controles en el Formulario: " +
            Controls.Count);
        }

        private void btPanel_Click(object sender, EventArgs e)
        {
            foreach (Control micontrol in pnBotones.Controls)
            {
                if (micontrol is Button) // usamos el operador de clase is
                {
                    micontrol.ForeColor = Color.Red;
                }
                MessageBox.Show(micontrol.Name);
            }

            MessageBox.Show("Total Controles en el panel: " + pnBotones.Controls.Count);
        }

        private void btUno_Click(object sender, EventArgs e)
        {
            if (sender == btUno)
            {
                MessageBox.Show("es el uno");
            }
            if (sender == btDos)
            {
                MessageBox.Show("es el dos");
            }
            if (sender == btTres)
            {
                MessageBox.Show("es el tres");
            }

            (sender as Button).BackColor = Color.Red; //Cambiamos color de fondo al botón
            Button miBoton = (Button)sender; //Asignamos sender a variable de objeto button moldeándolo
            MessageBox.Show("Es el boton " + miBoton.Text);
        }

        private void btCreaBoton_Click(object sender, EventArgs e)
        {
            Button miboton = new Button();// Creación Objeto
            miboton.Text = "Mi botón";
            miboton.Size = new System.Drawing.Size(100, 25);
            miboton.Location = new System.Drawing.Point(470, 300);
            miboton.Parent = this; // Obligatorio asignar contenedor
            miboton.TabIndex = 25; //Indice para secuencia de salto con Tab
            miboton.UseVisualStyleBackColor = true; // fondo estilo visual
            miboton.Click += new System.EventHandler(miboton_Click);//nuevo evento
        }

        private void miboton_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Click del Nuevo Botón Creado");
        }

        private void btAcercaDe_Click(object sender, EventArgs e)
        {
            new fmAcercade().ShowDialog();
        }

        private void btSalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
