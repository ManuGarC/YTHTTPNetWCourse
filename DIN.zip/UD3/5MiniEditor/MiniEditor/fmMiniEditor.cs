﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MiniEditor
{
    public partial class fmMiniEditor : System.Windows.Forms.Form
    {
        fmAcercade VentanaAcercade;

        public fmMiniEditor()
        {
            InitializeComponent();
        }

        private void btAbrir_Click(object sender, EventArgs e)
        {
            if (tbNombre.Text == "") //Comprobación de que hay nombre para abrir
            {
                MessageBox.Show("Pon un nombre");
                tbNombre.Focus();
            }
            else
            {
                rtbEditor.Clear();
                try
                { //Método que lee un archivo de formato rtf de la subcarpeta
                  //indicada con path relativo
                    rtbEditor.LoadFile(@".\archivos\" + tbNombre.Text + ".rtf");
                }
                catch (Exception error)
                {
                    MessageBox.Show(error.Message);
                }
                rtbEditor.Focus();
            }
        }

        private void btGuardar_Click(object sender, EventArgs e)
        {
            if (tbNombre.Text == "") //Comprobación que haya un nombre al guardar el archivo.
            {
                MessageBox.Show("El archivo debe de tener un nombre antes de poder guardar.");
                tbNombre.Focus();
            }
            else
            {
                try
                { 
                    //Guardamos un archivo . rtf en la ruta indicada en el path relativo
                    rtbEditor.SaveFile(@".\archivos\" + tbNombre.Text + ".rtf");
                }
                catch (Exception error)
                {
                    MessageBox.Show(error.Message);
                }
                rtbEditor.Focus();
            }
        }

        private void itCortar_Click(object sender, EventArgs e)
        {
            rtbEditor.Cut();
        }

        private void itCopiar_Click(object sender, EventArgs e)
        {
            rtbEditor.Copy();
        }

        private void itPegar_Click(object sender, EventArgs e)
        {
            rtbEditor.Paste();
        }

        private void itVaciar_Click(object sender, EventArgs e)
        {
            Clipboard.Clear();
        }

        private void itDeshacer_Click(object sender, EventArgs e)
        {
            if (rtbEditor.CanUndo)
            {
                rtbEditor.Undo();
            }
        }

        private void itRehacer_Click(object sender, EventArgs e)
        {
            if (rtbEditor.CanRedo)
            {
                rtbEditor.Redo();
            }
        }

        private void totiEditor_Popup(object sender, PopupEventArgs e)
        {
            if (e.AssociatedControl == lbColores)
                laEstado.Text = "Colorea con el color indicado el texto seleccionado.";
            else if (e.AssociatedControl == cbFuentes)
                laEstado.Text = "Selector de la fuente aplicada en el texto seleccionado del editor.";
            else if (e.AssociatedControl == cbTamanyo)
                laEstado.Text = "Modifica el tamaño de la fuente del texto seleccionado en el editor.";
            else if (e.AssociatedControl == btGuardar)
                laEstado.Text = "Guarda el contenido del editor en un documento con el nombre especificado en Nombre.";
            else if (e.AssociatedControl == btAbrir)
                laEstado.Text = "Abre un documento con el nombre especificado en el campo Nombre.";
            else if (e.AssociatedControl == tbNombre)
                laEstado.Text = "Contiene el nombre del documento a abrir o guardar.";
            else if (e.AssociatedControl == ckNegrita)
                laEstado.Text = "Cambia el estilo del texto seleccionado a negrita.";
            else if (e.AssociatedControl == ckSubrayado)
                laEstado.Text = "Agrega un subrayado al texto seleccionado en el editor.";
            else if (e.AssociatedControl == ckCursiva)
                laEstado.Text = "Cambia el estilo del texto seleccionado a cursiva.";
            else if (e.AssociatedControl == ckTachado)
                laEstado.Text = "Agrega un tachado al texto seleccionado en el editor.";
            else if (e.AssociatedControl == rbIzq)
                laEstado.Text = "Mueve la alineación del texto del editor a la izquierda.";
            else if (e.AssociatedControl == rbCent)
                laEstado.Text = "Mueve la alineación del texto del editor al centro.";
            else if (e.AssociatedControl == rbDer)
                laEstado.Text = "Mueve la alineación del texto del editor a la derecha.";
        }

        private void fmMiniEditor_Load(object sender, EventArgs e)
        {
            // Cargamos el combobox de las fuentes con las instaladas en el sistema
            foreach (FontFamily misfuentes in FontFamily.Families)
            {
                cbFuentes.Items.Add(misfuentes.Name);
            }
            // Elegimos una fuente por defecto
            cbFuentes.Text = "Microsoft Sans Serif";
            // Ponemos tamaño elegido
            cbTamanyo.Text = "9";
        }

        private void rbIzq_CheckedChanged(object sender, EventArgs e)
        {
            //Código para alinear según el radiobutton elegido
            if (rbIzq.Checked)
            {
                rtbEditor.SelectionAlignment = HorizontalAlignment.Left;
            }
            if (rbCent.Checked)
            {
                rtbEditor.SelectionAlignment = HorizontalAlignment.Center;
            }
            if (rbDer.Checked)
            {
                rtbEditor.SelectionAlignment = HorizontalAlignment.Right;
            }
            rtbEditor.Focus();
            //Sincronizamos con los ítems del menú marcándolos también o no
            itCent.Checked = rbCent.Checked;
            itDer.Checked = rbDer.Checked;
            itIzq.Checked = rbIzq.Checked;
        }

        private void itIzq_Click(object sender, EventArgs e)
        {
            rbIzq.Checked = true; //lo mismo para los otros items
        }

        private void itCent_Click(object sender, EventArgs e)
        {
            rbCent.Checked = true;
        }

        private void itDer_Click(object sender, EventArgs e)
        {
            rbDer.Checked = true;
        }

        private void cbTamanyo_TextChanged(object sender, EventArgs e)
        {
            if (cbTamanyo.Text != "")
            { //Aplicamos solo nuevo tamaño dejando el resto como estaba
                rtbEditor.SelectionFont = new Font(rtbEditor.SelectionFont.Name,
                Convert.ToInt32(cbTamanyo.Text), rtbEditor.SelectionFont.Style);
            }
        }

        private void cbTamanyo_KeyPress(object sender, KeyPressEventArgs e)
        {
            switch (e.KeyChar)
            {
                //Solo aceptamos números.
                case '1':
                case '2':
                case '3':
                case '4':
                case '5':
                case '6':
                case '7':
                case '8':
                case '9':
                case '0':
                    break;
                case (char)8:  //Permitimos borrar con retroceso.
                case (char)127: //Permitimos suprimir.
                case (char)13:  //Cambiamos el focus al editor con Enter.
                    rtbEditor.Focus();
                    break;
                default:
                    e.KeyChar = (char)0; //anulamos la pulsación
                    break;
            }
        }

        private void cbFuentes_TextChanged(object sender, EventArgs e)
        {
            //Aplicamos nuevo tipo de fuente dejando estilo y tamaño anterior
            rtbEditor.SelectionFont = new Font(cbFuentes.Text,
            rtbEditor.SelectionFont.Size, rtbEditor.SelectionFont.Style);
            rtbEditor.Focus();
        }

        private void itNuevo_Click(object sender, EventArgs e)
        {
            rtbEditor.Clear();
        }

        private void ckNegrita_CheckedChanged(object sender, EventArgs e)
        {
            FontStyle negrita = new FontStyle();//Variables para establecer el estilo
            FontStyle subrayado = new FontStyle();//de fuente de un texto seleccionado
            FontStyle tachado = new FontStyle();//FontStyle Define una estructura que
            FontStyle cursiva = new FontStyle(); // representa el estilo de una fuente
            if (ckNegrita.Checked)// En función de los checkBox y de su marca
            { // asignamos valor a variables o no
                negrita = FontStyle.Bold;
            }
            if (ckSubrayado.Checked)
            {
                subrayado = FontStyle.Underline;
            }
            if (ckTachado.Checked)
            {
                tachado = FontStyle.Strikeout;
            }
            if (ckCursiva.Checked)
            {
                cursiva = FontStyle.Italic;
            }
            itNegrita.Checked = ckNegrita.Checked; //Marcamos los correspondientes
            itSubrayado.Checked = ckSubrayado.Checked; // ítems de menú o no
            itTachado.Checked = ckTachado.Checked; // En función de las marcas de los
            itCursiva.Checked = ckCursiva.Checked; // CheckBox
            rtbEditor.SelectionFont = //Aplicamos nuevos estilos
            new Font(rtbEditor.SelectionFont, negrita | subrayado | tachado | cursiva);
            rtbEditor.Focus();
        }

        private void itNegrita_Click(object sender, EventArgs e)
        {
            ckNegrita.Checked = !ckNegrita.Checked; //Se pone true o false,
        }   // dependiendo de cual era el estado anterior.

        private void itSubrayado_Click(object sender, EventArgs e)
        {
            ckSubrayado.Checked = !ckSubrayado.Checked;
        }

        private void itCursiva_Click(object sender, EventArgs e)
        {
            ckCursiva.Checked = !ckCursiva.Checked;
        }

        private void itTachado_Click(object sender, EventArgs e)
        {
            ckTachado.Checked = !ckTachado.Checked;
        }

        private void lbColores_SelectedIndexChanged(object sender, EventArgs e)
        {
            int indice = 0;
            if (sender is ToolStripMenuItem) //true cuando hacen click en el menú
            { // en cualquier ítem de color
                ToolStripMenuItem elemento = sender as ToolStripMenuItem;//Guardamos
                                                                         //ítem clikado usando clase indicada en variable
                if (elemento != null) //Por si hay error en el click
                {
                    //Como las denominaciones de los ítems del menú y de los
                    // ítems del listbox son iguales se pueden buscar para seleccionar
                    // usando el índice Seleccionado del listbox
                    indice = itColores.DropDownItems.IndexOf(elemento);
                    lbColores.SelectedIndex = indice;
                }
            }
            else//sucede cuando se hace click en el Listbox
            { //bucle que se repite tantas veces como elementos hay en listbox
                for (int i = 0; i < lbColores.Items.Count; i++)
                { // Como los ítems son los mismos desmarcamos todos uno a uno
                    ((ToolStripMenuItem)itColores.DropDownItems[i]).Checked = false;
                }
                indice = lbColores.SelectedIndex; //Guardamos índice elemento
                                                  // seleccionado del listbox
            }
            //Marcamos ítem del menú colores usando el vector
            // que pertenece a itColores, los subitem son los colores
            ((ToolStripMenuItem)itColores.DropDownItems[indice]).Checked = true;
            Color micolor = Color.Black; // Definimos variable para color
            switch (lbColores.SelectedIndex) //Asignamos constante de color según
            { //elemento seleccionado
                case 0:
                    micolor = Color.Red;
                    break;
                case 1:
                    micolor = Color.Green;
                    break;
                case 2:
                    micolor = Color.Blue;
                    break;
                case 3:
                    micolor = Color.Gray;
                    break;
                case 4:
                    micolor = Color.Orange;
                    break;
                case 5:
                    micolor = Color.Yellow;
                    break;
                case 6:
                    micolor = Color.Black;
                    break;
            }
            rtbEditor.SelectionColor = micolor; //Aplicamos color a la selección
                                                // de texto del RichTextBox
            rtbEditor.Focus();
        }

        private void itSalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void itAcercade_Click(object sender, EventArgs e)
        {
            VentanaAcercade = new fmAcercade();
            VentanaAcercade.ShowDialog();
            VentanaAcercade.Dispose();
        }
    }
}
