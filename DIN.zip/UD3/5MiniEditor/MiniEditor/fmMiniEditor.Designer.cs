﻿namespace MiniEditor
{
    partial class fmMiniEditor
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.mnEditor = new System.Windows.Forms.MenuStrip();
            this.archivoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.itNuevo = new System.Windows.Forms.ToolStripMenuItem();
            this.itAbrir = new System.Windows.Forms.ToolStripMenuItem();
            this.itGuardar = new System.Windows.Forms.ToolStripMenuItem();
            this.itSalir = new System.Windows.Forms.ToolStripMenuItem();
            this.edicionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.itCortar = new System.Windows.Forms.ToolStripMenuItem();
            this.itCopiar = new System.Windows.Forms.ToolStripMenuItem();
            this.itPegar = new System.Windows.Forms.ToolStripMenuItem();
            this.itVaciar = new System.Windows.Forms.ToolStripMenuItem();
            this.itDeshacer = new System.Windows.Forms.ToolStripMenuItem();
            this.itRehacer = new System.Windows.Forms.ToolStripMenuItem();
            this.formatoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.itAlineacion = new System.Windows.Forms.ToolStripMenuItem();
            this.itIzq = new System.Windows.Forms.ToolStripMenuItem();
            this.itCent = new System.Windows.Forms.ToolStripMenuItem();
            this.itDer = new System.Windows.Forms.ToolStripMenuItem();
            this.itEstilo = new System.Windows.Forms.ToolStripMenuItem();
            this.itNegrita = new System.Windows.Forms.ToolStripMenuItem();
            this.itSubrayado = new System.Windows.Forms.ToolStripMenuItem();
            this.itCursiva = new System.Windows.Forms.ToolStripMenuItem();
            this.itTachado = new System.Windows.Forms.ToolStripMenuItem();
            this.itColores = new System.Windows.Forms.ToolStripMenuItem();
            this.rojoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.verdeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.azulToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.grisToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.amarilloToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.naranjaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.negroToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ayudaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.itAcercade = new System.Windows.Forms.ToolStripMenuItem();
            this.pnControles = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.lbColores = new System.Windows.Forms.ListBox();
            this.tbNombre = new System.Windows.Forms.TextBox();
            this.btGuardar = new System.Windows.Forms.Button();
            this.btAbrir = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.cbTamanyo = new System.Windows.Forms.ComboBox();
            this.cbFuentes = new System.Windows.Forms.ComboBox();
            this.gbAlineacion = new System.Windows.Forms.GroupBox();
            this.rbDer = new System.Windows.Forms.RadioButton();
            this.rbCent = new System.Windows.Forms.RadioButton();
            this.rbIzq = new System.Windows.Forms.RadioButton();
            this.gbEstilo = new System.Windows.Forms.GroupBox();
            this.ckTachado = new System.Windows.Forms.CheckBox();
            this.ckCursiva = new System.Windows.Forms.CheckBox();
            this.ckSubrayado = new System.Windows.Forms.CheckBox();
            this.ckNegrita = new System.Windows.Forms.CheckBox();
            this.pnEstado = new System.Windows.Forms.Panel();
            this.laEstado = new System.Windows.Forms.Label();
            this.rtbEditor = new System.Windows.Forms.RichTextBox();
            this.cmnEditor = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.itcCortar = new System.Windows.Forms.ToolStripMenuItem();
            this.itcCopiar = new System.Windows.Forms.ToolStripMenuItem();
            this.itcPegar = new System.Windows.Forms.ToolStripMenuItem();
            this.itcVaciar = new System.Windows.Forms.ToolStripMenuItem();
            this.itcDeshacer = new System.Windows.Forms.ToolStripMenuItem();
            this.itcRehacer = new System.Windows.Forms.ToolStripMenuItem();
            this.totiEditor = new System.Windows.Forms.ToolTip(this.components);
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
            this.mnEditor.SuspendLayout();
            this.pnControles.SuspendLayout();
            this.gbAlineacion.SuspendLayout();
            this.gbEstilo.SuspendLayout();
            this.pnEstado.SuspendLayout();
            this.cmnEditor.SuspendLayout();
            this.SuspendLayout();
            // 
            // mnEditor
            // 
            this.mnEditor.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.archivoToolStripMenuItem,
            this.edicionToolStripMenuItem,
            this.formatoToolStripMenuItem,
            this.ayudaToolStripMenuItem});
            this.mnEditor.Location = new System.Drawing.Point(0, 0);
            this.mnEditor.Name = "mnEditor";
            this.mnEditor.Size = new System.Drawing.Size(800, 24);
            this.mnEditor.TabIndex = 0;
            this.mnEditor.Text = "menuStrip1";
            // 
            // archivoToolStripMenuItem
            // 
            this.archivoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.itNuevo,
            this.toolStripSeparator1,
            this.itAbrir,
            this.itGuardar,
            this.toolStripSeparator2,
            this.itSalir});
            this.archivoToolStripMenuItem.Name = "archivoToolStripMenuItem";
            this.archivoToolStripMenuItem.Size = new System.Drawing.Size(60, 20);
            this.archivoToolStripMenuItem.Text = "A&rchivo";
            // 
            // itNuevo
            // 
            this.itNuevo.Name = "itNuevo";
            this.itNuevo.Size = new System.Drawing.Size(180, 22);
            this.itNuevo.Text = "&Nuevo";
            this.itNuevo.Click += new System.EventHandler(this.itNuevo_Click);
            // 
            // itAbrir
            // 
            this.itAbrir.Name = "itAbrir";
            this.itAbrir.Size = new System.Drawing.Size(180, 22);
            this.itAbrir.Text = "&Abrir";
            this.itAbrir.Click += new System.EventHandler(this.btAbrir_Click);
            // 
            // itGuardar
            // 
            this.itGuardar.Name = "itGuardar";
            this.itGuardar.Size = new System.Drawing.Size(180, 22);
            this.itGuardar.Text = "Guardar";
            this.itGuardar.Click += new System.EventHandler(this.btGuardar_Click);
            // 
            // itSalir
            // 
            this.itSalir.Name = "itSalir";
            this.itSalir.Size = new System.Drawing.Size(180, 22);
            this.itSalir.Text = "Salir";
            this.itSalir.Click += new System.EventHandler(this.itSalir_Click);
            // 
            // edicionToolStripMenuItem
            // 
            this.edicionToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.itCortar,
            this.itCopiar,
            this.itPegar,
            this.toolStripSeparator4,
            this.itVaciar,
            this.toolStripSeparator3,
            this.itDeshacer,
            this.itRehacer});
            this.edicionToolStripMenuItem.Name = "edicionToolStripMenuItem";
            this.edicionToolStripMenuItem.Size = new System.Drawing.Size(58, 20);
            this.edicionToolStripMenuItem.Text = "Edicion";
            // 
            // itCortar
            // 
            this.itCortar.Name = "itCortar";
            this.itCortar.ShortcutKeyDisplayString = "";
            this.itCortar.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.X)));
            this.itCortar.Size = new System.Drawing.Size(180, 22);
            this.itCortar.Text = "Cortar";
            this.itCortar.Click += new System.EventHandler(this.itCortar_Click);
            // 
            // itCopiar
            // 
            this.itCopiar.Name = "itCopiar";
            this.itCopiar.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.C)));
            this.itCopiar.Size = new System.Drawing.Size(180, 22);
            this.itCopiar.Text = "Copiar";
            this.itCopiar.Click += new System.EventHandler(this.itCopiar_Click);
            // 
            // itPegar
            // 
            this.itPegar.Name = "itPegar";
            this.itPegar.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.V)));
            this.itPegar.Size = new System.Drawing.Size(180, 22);
            this.itPegar.Text = "Pegar";
            this.itPegar.Click += new System.EventHandler(this.itPegar_Click);
            // 
            // itVaciar
            // 
            this.itVaciar.Name = "itVaciar";
            this.itVaciar.Size = new System.Drawing.Size(180, 22);
            this.itVaciar.Text = "Vaciar Portapapeles";
            this.itVaciar.Click += new System.EventHandler(this.itVaciar_Click);
            // 
            // itDeshacer
            // 
            this.itDeshacer.Name = "itDeshacer";
            this.itDeshacer.Size = new System.Drawing.Size(180, 22);
            this.itDeshacer.Text = "Deshacer";
            this.itDeshacer.Click += new System.EventHandler(this.itDeshacer_Click);
            // 
            // itRehacer
            // 
            this.itRehacer.Name = "itRehacer";
            this.itRehacer.Size = new System.Drawing.Size(180, 22);
            this.itRehacer.Text = "Rehacer";
            this.itRehacer.Click += new System.EventHandler(this.itRehacer_Click);
            // 
            // formatoToolStripMenuItem
            // 
            this.formatoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.itAlineacion,
            this.itEstilo,
            this.itColores});
            this.formatoToolStripMenuItem.Name = "formatoToolStripMenuItem";
            this.formatoToolStripMenuItem.Size = new System.Drawing.Size(64, 20);
            this.formatoToolStripMenuItem.Text = "&Formato";
            // 
            // itAlineacion
            // 
            this.itAlineacion.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.itIzq,
            this.itCent,
            this.itDer});
            this.itAlineacion.Name = "itAlineacion";
            this.itAlineacion.Size = new System.Drawing.Size(180, 22);
            this.itAlineacion.Text = "&Alineacion";
            // 
            // itIzq
            // 
            this.itIzq.Checked = true;
            this.itIzq.CheckState = System.Windows.Forms.CheckState.Checked;
            this.itIzq.Name = "itIzq";
            this.itIzq.Size = new System.Drawing.Size(180, 22);
            this.itIzq.Text = "&Izquierda";
            this.itIzq.Click += new System.EventHandler(this.itIzq_Click);
            // 
            // itCent
            // 
            this.itCent.Name = "itCent";
            this.itCent.Size = new System.Drawing.Size(180, 22);
            this.itCent.Text = "Centrada";
            this.itCent.Click += new System.EventHandler(this.itCent_Click);
            // 
            // itDer
            // 
            this.itDer.Name = "itDer";
            this.itDer.Size = new System.Drawing.Size(180, 22);
            this.itDer.Text = "Derecha";
            this.itDer.Click += new System.EventHandler(this.itDer_Click);
            // 
            // itEstilo
            // 
            this.itEstilo.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.itNegrita,
            this.itSubrayado,
            this.itCursiva,
            this.itTachado});
            this.itEstilo.Name = "itEstilo";
            this.itEstilo.Size = new System.Drawing.Size(180, 22);
            this.itEstilo.Text = "Estilo";
            // 
            // itNegrita
            // 
            this.itNegrita.Name = "itNegrita";
            this.itNegrita.Size = new System.Drawing.Size(130, 22);
            this.itNegrita.Text = "Negrita";
            this.itNegrita.Click += new System.EventHandler(this.itNegrita_Click);
            // 
            // itSubrayado
            // 
            this.itSubrayado.Name = "itSubrayado";
            this.itSubrayado.Size = new System.Drawing.Size(130, 22);
            this.itSubrayado.Text = "Subrayado";
            this.itSubrayado.Click += new System.EventHandler(this.itSubrayado_Click);
            // 
            // itCursiva
            // 
            this.itCursiva.Name = "itCursiva";
            this.itCursiva.Size = new System.Drawing.Size(130, 22);
            this.itCursiva.Text = "Cursiva";
            this.itCursiva.Click += new System.EventHandler(this.itCursiva_Click);
            // 
            // itTachado
            // 
            this.itTachado.Name = "itTachado";
            this.itTachado.Size = new System.Drawing.Size(130, 22);
            this.itTachado.Text = "Tachado";
            this.itTachado.Click += new System.EventHandler(this.itTachado_Click);
            // 
            // itColores
            // 
            this.itColores.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.rojoToolStripMenuItem,
            this.verdeToolStripMenuItem,
            this.azulToolStripMenuItem,
            this.grisToolStripMenuItem,
            this.amarilloToolStripMenuItem,
            this.naranjaToolStripMenuItem,
            this.negroToolStripMenuItem});
            this.itColores.Name = "itColores";
            this.itColores.Size = new System.Drawing.Size(180, 22);
            this.itColores.Text = "Colores";
            // 
            // rojoToolStripMenuItem
            // 
            this.rojoToolStripMenuItem.Name = "rojoToolStripMenuItem";
            this.rojoToolStripMenuItem.Size = new System.Drawing.Size(119, 22);
            this.rojoToolStripMenuItem.Text = "Rojo";
            this.rojoToolStripMenuItem.Click += new System.EventHandler(this.lbColores_SelectedIndexChanged);
            // 
            // verdeToolStripMenuItem
            // 
            this.verdeToolStripMenuItem.Name = "verdeToolStripMenuItem";
            this.verdeToolStripMenuItem.Size = new System.Drawing.Size(119, 22);
            this.verdeToolStripMenuItem.Text = "Verde";
            this.verdeToolStripMenuItem.Click += new System.EventHandler(this.lbColores_SelectedIndexChanged);
            // 
            // azulToolStripMenuItem
            // 
            this.azulToolStripMenuItem.Name = "azulToolStripMenuItem";
            this.azulToolStripMenuItem.Size = new System.Drawing.Size(119, 22);
            this.azulToolStripMenuItem.Text = "Azul";
            this.azulToolStripMenuItem.Click += new System.EventHandler(this.lbColores_SelectedIndexChanged);
            // 
            // grisToolStripMenuItem
            // 
            this.grisToolStripMenuItem.Name = "grisToolStripMenuItem";
            this.grisToolStripMenuItem.Size = new System.Drawing.Size(119, 22);
            this.grisToolStripMenuItem.Text = "Gris";
            this.grisToolStripMenuItem.Click += new System.EventHandler(this.lbColores_SelectedIndexChanged);
            // 
            // amarilloToolStripMenuItem
            // 
            this.amarilloToolStripMenuItem.Name = "amarilloToolStripMenuItem";
            this.amarilloToolStripMenuItem.Size = new System.Drawing.Size(119, 22);
            this.amarilloToolStripMenuItem.Text = "Amarillo";
            this.amarilloToolStripMenuItem.Click += new System.EventHandler(this.lbColores_SelectedIndexChanged);
            // 
            // naranjaToolStripMenuItem
            // 
            this.naranjaToolStripMenuItem.Name = "naranjaToolStripMenuItem";
            this.naranjaToolStripMenuItem.Size = new System.Drawing.Size(119, 22);
            this.naranjaToolStripMenuItem.Text = "Naranja";
            this.naranjaToolStripMenuItem.Click += new System.EventHandler(this.lbColores_SelectedIndexChanged);
            // 
            // negroToolStripMenuItem
            // 
            this.negroToolStripMenuItem.Name = "negroToolStripMenuItem";
            this.negroToolStripMenuItem.Size = new System.Drawing.Size(119, 22);
            this.negroToolStripMenuItem.Text = "Negro";
            this.negroToolStripMenuItem.Click += new System.EventHandler(this.lbColores_SelectedIndexChanged);
            // 
            // ayudaToolStripMenuItem
            // 
            this.ayudaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.itAcercade});
            this.ayudaToolStripMenuItem.Name = "ayudaToolStripMenuItem";
            this.ayudaToolStripMenuItem.Size = new System.Drawing.Size(53, 20);
            this.ayudaToolStripMenuItem.Text = "Ayuda";
            // 
            // itAcercade
            // 
            this.itAcercade.Name = "itAcercade";
            this.itAcercade.Size = new System.Drawing.Size(126, 22);
            this.itAcercade.Text = "Acerca de";
            this.itAcercade.Click += new System.EventHandler(this.itAcercade_Click);
            // 
            // pnControles
            // 
            this.pnControles.BackColor = System.Drawing.Color.LightGray;
            this.pnControles.Controls.Add(this.label4);
            this.pnControles.Controls.Add(this.lbColores);
            this.pnControles.Controls.Add(this.tbNombre);
            this.pnControles.Controls.Add(this.btGuardar);
            this.pnControles.Controls.Add(this.btAbrir);
            this.pnControles.Controls.Add(this.label3);
            this.pnControles.Controls.Add(this.label2);
            this.pnControles.Controls.Add(this.label1);
            this.pnControles.Controls.Add(this.cbTamanyo);
            this.pnControles.Controls.Add(this.cbFuentes);
            this.pnControles.Controls.Add(this.gbAlineacion);
            this.pnControles.Controls.Add(this.gbEstilo);
            this.pnControles.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnControles.Location = new System.Drawing.Point(0, 24);
            this.pnControles.Name = "pnControles";
            this.pnControles.Size = new System.Drawing.Size(800, 195);
            this.pnControles.TabIndex = 1;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(265, 65);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(82, 13);
            this.label4.TabIndex = 11;
            this.label4.Text = "Color de Fuente";
            // 
            // lbColores
            // 
            this.lbColores.FormattingEnabled = true;
            this.lbColores.Items.AddRange(new object[] {
            "Rojo",
            "Verde",
            "Azul",
            "Gris",
            "Naranja",
            "Amarillo",
            "Negro"});
            this.lbColores.Location = new System.Drawing.Point(268, 81);
            this.lbColores.Name = "lbColores";
            this.lbColores.Size = new System.Drawing.Size(120, 95);
            this.lbColores.TabIndex = 10;
            this.totiEditor.SetToolTip(this.lbColores, "Cambia el color del texto en el editor.");
            this.lbColores.SelectedIndexChanged += new System.EventHandler(this.lbColores_SelectedIndexChanged);
            // 
            // tbNombre
            // 
            this.tbNombre.Location = new System.Drawing.Point(55, 156);
            this.tbNombre.Name = "tbNombre";
            this.tbNombre.Size = new System.Drawing.Size(100, 20);
            this.tbNombre.TabIndex = 9;
            this.totiEditor.SetToolTip(this.tbNombre, "Nombre del documento.");
            // 
            // btGuardar
            // 
            this.btGuardar.Location = new System.Drawing.Point(55, 108);
            this.btGuardar.Name = "btGuardar";
            this.btGuardar.Size = new System.Drawing.Size(85, 23);
            this.btGuardar.TabIndex = 8;
            this.btGuardar.Text = "Guardar";
            this.totiEditor.SetToolTip(this.btGuardar, "Guarda los cambios realizados en el editor en el documento.");
            this.btGuardar.UseVisualStyleBackColor = true;
            this.btGuardar.Click += new System.EventHandler(this.btGuardar_Click);
            // 
            // btAbrir
            // 
            this.btAbrir.Location = new System.Drawing.Point(55, 79);
            this.btAbrir.Name = "btAbrir";
            this.btAbrir.Size = new System.Drawing.Size(85, 23);
            this.btAbrir.TabIndex = 7;
            this.btAbrir.Text = "Abrir";
            this.totiEditor.SetToolTip(this.btAbrir, "Abre un nuevo documento.");
            this.btAbrir.UseVisualStyleBackColor = true;
            this.btAbrir.Click += new System.EventHandler(this.btAbrir_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(52, 140);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(44, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "Nombre";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(256, 20);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(46, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Tamaño";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(33, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(40, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Fuente";
            // 
            // cbTamanyo
            // 
            this.cbTamanyo.FormattingEnabled = true;
            this.cbTamanyo.Items.AddRange(new object[] {
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20",
            "21",
            "22",
            "23",
            "24",
            "25",
            "26",
            "27",
            "28",
            "30",
            "32",
            "34",
            "36",
            "38",
            "40",
            "42",
            "44",
            "46",
            "50",
            "54",
            "58",
            "62",
            "66",
            "70",
            "78",
            "86",
            "94"});
            this.cbTamanyo.Location = new System.Drawing.Point(259, 36);
            this.cbTamanyo.MaxLength = 3;
            this.cbTamanyo.Name = "cbTamanyo";
            this.cbTamanyo.Size = new System.Drawing.Size(78, 21);
            this.cbTamanyo.TabIndex = 3;
            this.totiEditor.SetToolTip(this.cbTamanyo, "Indica el Tamaño de la fuente.");
            this.cbTamanyo.TextChanged += new System.EventHandler(this.cbTamanyo_TextChanged);
            this.cbTamanyo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cbTamanyo_KeyPress);
            // 
            // cbFuentes
            // 
            this.cbFuentes.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbFuentes.FormattingEnabled = true;
            this.cbFuentes.Location = new System.Drawing.Point(36, 36);
            this.cbFuentes.Name = "cbFuentes";
            this.cbFuentes.Size = new System.Drawing.Size(134, 21);
            this.cbFuentes.TabIndex = 2;
            this.totiEditor.SetToolTip(this.cbFuentes, "Indica el tipo de la Fuente.");
            this.cbFuentes.TextChanged += new System.EventHandler(this.cbFuentes_TextChanged);
            // 
            // gbAlineacion
            // 
            this.gbAlineacion.Controls.Add(this.rbDer);
            this.gbAlineacion.Controls.Add(this.rbCent);
            this.gbAlineacion.Controls.Add(this.rbIzq);
            this.gbAlineacion.Location = new System.Drawing.Point(630, 36);
            this.gbAlineacion.Name = "gbAlineacion";
            this.gbAlineacion.Size = new System.Drawing.Size(133, 100);
            this.gbAlineacion.TabIndex = 1;
            this.gbAlineacion.TabStop = false;
            this.gbAlineacion.Text = "Alineación";
            // 
            // rbDer
            // 
            this.rbDer.AutoSize = true;
            this.rbDer.Location = new System.Drawing.Point(43, 65);
            this.rbDer.Name = "rbDer";
            this.rbDer.Size = new System.Drawing.Size(66, 17);
            this.rbDer.TabIndex = 2;
            this.rbDer.Text = "Derecha";
            this.totiEditor.SetToolTip(this.rbDer, "Alinea el texto en el editor a la Derecha.");
            this.rbDer.UseVisualStyleBackColor = true;
            this.rbDer.CheckedChanged += new System.EventHandler(this.rbIzq_CheckedChanged);
            // 
            // rbCent
            // 
            this.rbCent.AutoSize = true;
            this.rbCent.Location = new System.Drawing.Point(43, 42);
            this.rbCent.Name = "rbCent";
            this.rbCent.Size = new System.Drawing.Size(68, 17);
            this.rbCent.TabIndex = 1;
            this.rbCent.Text = "Centrada";
            this.totiEditor.SetToolTip(this.rbCent, "Alinea al centro el texto del editor.");
            this.rbCent.UseVisualStyleBackColor = true;
            this.rbCent.CheckedChanged += new System.EventHandler(this.rbIzq_CheckedChanged);
            // 
            // rbIzq
            // 
            this.rbIzq.AutoSize = true;
            this.rbIzq.Checked = true;
            this.rbIzq.Location = new System.Drawing.Point(43, 19);
            this.rbIzq.Name = "rbIzq";
            this.rbIzq.Size = new System.Drawing.Size(68, 17);
            this.rbIzq.TabIndex = 0;
            this.rbIzq.TabStop = true;
            this.rbIzq.Text = "Izquierda";
            this.totiEditor.SetToolTip(this.rbIzq, "Alinea el texto en el editor a la izquierda.");
            this.rbIzq.UseVisualStyleBackColor = true;
            this.rbIzq.CheckedChanged += new System.EventHandler(this.rbIzq_CheckedChanged);
            // 
            // gbEstilo
            // 
            this.gbEstilo.Controls.Add(this.ckTachado);
            this.gbEstilo.Controls.Add(this.ckCursiva);
            this.gbEstilo.Controls.Add(this.ckSubrayado);
            this.gbEstilo.Controls.Add(this.ckNegrita);
            this.gbEstilo.Location = new System.Drawing.Point(446, 36);
            this.gbEstilo.Name = "gbEstilo";
            this.gbEstilo.Size = new System.Drawing.Size(135, 122);
            this.gbEstilo.TabIndex = 0;
            this.gbEstilo.TabStop = false;
            this.gbEstilo.Text = "Estilo";
            // 
            // ckTachado
            // 
            this.ckTachado.AutoSize = true;
            this.ckTachado.Location = new System.Drawing.Point(31, 89);
            this.ckTachado.Name = "ckTachado";
            this.ckTachado.Size = new System.Drawing.Size(69, 17);
            this.ckTachado.TabIndex = 3;
            this.ckTachado.Text = "Tachado";
            this.totiEditor.SetToolTip(this.ckTachado, "Tacha el texto seleccionado.");
            this.ckTachado.UseVisualStyleBackColor = true;
            this.ckTachado.CheckedChanged += new System.EventHandler(this.ckNegrita_CheckedChanged);
            // 
            // ckCursiva
            // 
            this.ckCursiva.AutoSize = true;
            this.ckCursiva.Location = new System.Drawing.Point(31, 66);
            this.ckCursiva.Name = "ckCursiva";
            this.ckCursiva.Size = new System.Drawing.Size(61, 17);
            this.ckCursiva.TabIndex = 2;
            this.ckCursiva.Text = "Cursiva";
            this.totiEditor.SetToolTip(this.ckCursiva, "Agrega al texto el estilo Cursiva.");
            this.ckCursiva.UseVisualStyleBackColor = true;
            this.ckCursiva.CheckedChanged += new System.EventHandler(this.ckNegrita_CheckedChanged);
            // 
            // ckSubrayado
            // 
            this.ckSubrayado.AutoSize = true;
            this.ckSubrayado.Location = new System.Drawing.Point(32, 43);
            this.ckSubrayado.Name = "ckSubrayado";
            this.ckSubrayado.Size = new System.Drawing.Size(77, 17);
            this.ckSubrayado.TabIndex = 1;
            this.ckSubrayado.Text = "Subrayado";
            this.totiEditor.SetToolTip(this.ckSubrayado, "Subraya el texto seleccionado.");
            this.ckSubrayado.UseVisualStyleBackColor = true;
            this.ckSubrayado.CheckedChanged += new System.EventHandler(this.ckNegrita_CheckedChanged);
            // 
            // ckNegrita
            // 
            this.ckNegrita.AutoSize = true;
            this.ckNegrita.Location = new System.Drawing.Point(32, 20);
            this.ckNegrita.Name = "ckNegrita";
            this.ckNegrita.Size = new System.Drawing.Size(60, 17);
            this.ckNegrita.TabIndex = 0;
            this.ckNegrita.Text = "Negrita";
            this.totiEditor.SetToolTip(this.ckNegrita, "Agrega al texto el estilo Negrita.");
            this.ckNegrita.UseVisualStyleBackColor = true;
            this.ckNegrita.CheckedChanged += new System.EventHandler(this.ckNegrita_CheckedChanged);
            // 
            // pnEstado
            // 
            this.pnEstado.BackColor = System.Drawing.Color.LightGray;
            this.pnEstado.Controls.Add(this.laEstado);
            this.pnEstado.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnEstado.ForeColor = System.Drawing.SystemColors.ControlText;
            this.pnEstado.Location = new System.Drawing.Point(0, 416);
            this.pnEstado.Name = "pnEstado";
            this.pnEstado.Size = new System.Drawing.Size(800, 34);
            this.pnEstado.TabIndex = 2;
            // 
            // laEstado
            // 
            this.laEstado.AutoSize = true;
            this.laEstado.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.laEstado.Location = new System.Drawing.Point(12, 10);
            this.laEstado.Name = "laEstado";
            this.laEstado.Size = new System.Drawing.Size(0, 15);
            this.laEstado.TabIndex = 0;
            // 
            // rtbEditor
            // 
            this.rtbEditor.ContextMenuStrip = this.cmnEditor;
            this.rtbEditor.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rtbEditor.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtbEditor.Location = new System.Drawing.Point(0, 219);
            this.rtbEditor.Name = "rtbEditor";
            this.rtbEditor.Size = new System.Drawing.Size(800, 197);
            this.rtbEditor.TabIndex = 3;
            this.rtbEditor.Text = "";
            // 
            // cmnEditor
            // 
            this.cmnEditor.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.itcCortar,
            this.itcCopiar,
            this.itcPegar,
            this.toolStripSeparator6,
            this.itcVaciar,
            this.toolStripSeparator5,
            this.itcDeshacer,
            this.itcRehacer});
            this.cmnEditor.Name = "cmnEditor";
            this.cmnEditor.Size = new System.Drawing.Size(177, 148);
            // 
            // itcCortar
            // 
            this.itcCortar.Name = "itcCortar";
            this.itcCortar.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.X)));
            this.itcCortar.Size = new System.Drawing.Size(176, 22);
            this.itcCortar.Text = "Cortar";
            this.itcCortar.Click += new System.EventHandler(this.itCortar_Click);
            // 
            // itcCopiar
            // 
            this.itcCopiar.Name = "itcCopiar";
            this.itcCopiar.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.C)));
            this.itcCopiar.Size = new System.Drawing.Size(176, 22);
            this.itcCopiar.Text = "Copiar";
            this.itcCopiar.Click += new System.EventHandler(this.itCopiar_Click);
            // 
            // itcPegar
            // 
            this.itcPegar.Name = "itcPegar";
            this.itcPegar.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.V)));
            this.itcPegar.Size = new System.Drawing.Size(176, 22);
            this.itcPegar.Text = "Pegar";
            this.itcPegar.Click += new System.EventHandler(this.itPegar_Click);
            // 
            // itcVaciar
            // 
            this.itcVaciar.Name = "itcVaciar";
            this.itcVaciar.Size = new System.Drawing.Size(176, 22);
            this.itcVaciar.Text = "Vaciar Portapapeles";
            this.itcVaciar.Click += new System.EventHandler(this.itVaciar_Click);
            // 
            // itcDeshacer
            // 
            this.itcDeshacer.Name = "itcDeshacer";
            this.itcDeshacer.Size = new System.Drawing.Size(176, 22);
            this.itcDeshacer.Text = "Deshacer";
            this.itcDeshacer.Click += new System.EventHandler(this.itDeshacer_Click);
            // 
            // itcRehacer
            // 
            this.itcRehacer.Name = "itcRehacer";
            this.itcRehacer.Size = new System.Drawing.Size(176, 22);
            this.itcRehacer.Text = "Rehacer";
            this.itcRehacer.Click += new System.EventHandler(this.itRehacer_Click);
            // 
            // totiEditor
            // 
            this.totiEditor.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Info;
            this.totiEditor.ToolTipTitle = "Editor:";
            this.totiEditor.Popup += new System.Windows.Forms.PopupEventHandler(this.totiEditor_Popup);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(177, 6);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(177, 6);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(177, 6);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(177, 6);
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(173, 6);
            // 
            // toolStripSeparator6
            // 
            this.toolStripSeparator6.Name = "toolStripSeparator6";
            this.toolStripSeparator6.Size = new System.Drawing.Size(173, 6);
            // 
            // fmMiniEditor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.rtbEditor);
            this.Controls.Add(this.pnEstado);
            this.Controls.Add(this.pnControles);
            this.Controls.Add(this.mnEditor);
            this.MainMenuStrip = this.mnEditor;
            this.Name = "fmMiniEditor";
            this.Text = "Editor de textos";
            this.Load += new System.EventHandler(this.fmMiniEditor_Load);
            this.mnEditor.ResumeLayout(false);
            this.mnEditor.PerformLayout();
            this.pnControles.ResumeLayout(false);
            this.pnControles.PerformLayout();
            this.gbAlineacion.ResumeLayout(false);
            this.gbAlineacion.PerformLayout();
            this.gbEstilo.ResumeLayout(false);
            this.gbEstilo.PerformLayout();
            this.pnEstado.ResumeLayout(false);
            this.pnEstado.PerformLayout();
            this.cmnEditor.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip mnEditor;
        private System.Windows.Forms.ToolStripMenuItem archivoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem itNuevo;
        private System.Windows.Forms.ToolStripMenuItem itAbrir;
        private System.Windows.Forms.ToolStripMenuItem itGuardar;
        private System.Windows.Forms.ToolStripMenuItem itSalir;
        private System.Windows.Forms.ToolStripMenuItem edicionToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem itCortar;
        private System.Windows.Forms.ToolStripMenuItem itCopiar;
        private System.Windows.Forms.ToolStripMenuItem itPegar;
        private System.Windows.Forms.ToolStripMenuItem itVaciar;
        private System.Windows.Forms.ToolStripMenuItem itDeshacer;
        private System.Windows.Forms.ToolStripMenuItem itRehacer;
        private System.Windows.Forms.ToolStripMenuItem formatoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem itAlineacion;
        private System.Windows.Forms.ToolStripMenuItem itIzq;
        private System.Windows.Forms.ToolStripMenuItem itCent;
        private System.Windows.Forms.ToolStripMenuItem itDer;
        private System.Windows.Forms.ToolStripMenuItem itEstilo;
        private System.Windows.Forms.ToolStripMenuItem itColores;
        private System.Windows.Forms.ToolStripMenuItem itNegrita;
        private System.Windows.Forms.ToolStripMenuItem itSubrayado;
        private System.Windows.Forms.ToolStripMenuItem itCursiva;
        private System.Windows.Forms.ToolStripMenuItem itTachado;
        private System.Windows.Forms.ToolStripMenuItem rojoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem verdeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem azulToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem grisToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem amarilloToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem naranjaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem negroToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ayudaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem itAcercade;
        private System.Windows.Forms.Panel pnControles;
        private System.Windows.Forms.Panel pnEstado;
        private System.Windows.Forms.RichTextBox rtbEditor;
        private System.Windows.Forms.GroupBox gbAlineacion;
        private System.Windows.Forms.GroupBox gbEstilo;
        private System.Windows.Forms.CheckBox ckNegrita;
        private System.Windows.Forms.CheckBox ckTachado;
        private System.Windows.Forms.CheckBox ckCursiva;
        private System.Windows.Forms.CheckBox ckSubrayado;
        private System.Windows.Forms.RadioButton rbDer;
        private System.Windows.Forms.RadioButton rbCent;
        private System.Windows.Forms.RadioButton rbIzq;
        private System.Windows.Forms.ComboBox cbTamanyo;
        private System.Windows.Forms.ComboBox cbFuentes;
        private System.Windows.Forms.Button btGuardar;
        private System.Windows.Forms.Button btAbrir;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ListBox lbColores;
        private System.Windows.Forms.TextBox tbNombre;
        private System.Windows.Forms.ContextMenuStrip cmnEditor;
        private System.Windows.Forms.ToolStripMenuItem itcCortar;
        private System.Windows.Forms.ToolStripMenuItem itcCopiar;
        private System.Windows.Forms.ToolStripMenuItem itcPegar;
        private System.Windows.Forms.ToolStripMenuItem itcVaciar;
        private System.Windows.Forms.ToolStripMenuItem itcDeshacer;
        private System.Windows.Forms.ToolStripMenuItem itcRehacer;
        private System.Windows.Forms.ToolTip totiEditor;
        private System.Windows.Forms.Label laEstado;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
    }
}

