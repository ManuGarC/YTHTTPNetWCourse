﻿namespace Editor
{
    partial class fmEditor
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(fmEditor));
            this.tsBarraEstandar = new System.Windows.Forms.ToolStrip();
            this.cmnBarras = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.itcBarraEstandar = new System.Windows.Forms.ToolStripMenuItem();
            this.itcBarraFormato = new System.Windows.Forms.ToolStripMenuItem();
            this.itcBarraEstado = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.tsBarraFormato = new System.Windows.Forms.ToolStrip();
            this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripSeparator7 = new System.Windows.Forms.ToolStripSeparator();
            this.cbFuentes = new System.Windows.Forms.ToolStripComboBox();
            this.toolStripSeparator8 = new System.Windows.Forms.ToolStripSeparator();
            this.cbTamanyo = new System.Windows.Forms.ToolStripComboBox();
            this.toolStripSeparator9 = new System.Windows.Forms.ToolStripSeparator();
            this.stEstadoEditor = new System.Windows.Forms.StatusStrip();
            this.sl1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.sl2 = new System.Windows.Forms.ToolStripStatusLabel();
            this.sl3 = new System.Windows.Forms.ToolStripStatusLabel();
            this.sl4 = new System.Windows.Forms.ToolStripStatusLabel();
            this.sl5 = new System.Windows.Forms.ToolStripStatusLabel();
            this.rtbEditor = new System.Windows.Forms.RichTextBox();
            this.cmnEditor = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.itcDeshacer = new System.Windows.Forms.ToolStripMenuItem();
            this.itcRehacer = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator19 = new System.Windows.Forms.ToolStripSeparator();
            this.itcCortar = new System.Windows.Forms.ToolStripMenuItem();
            this.itcCopiar = new System.Windows.Forms.ToolStripMenuItem();
            this.itcPegar = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator20 = new System.Windows.Forms.ToolStripSeparator();
            this.itcBorrar = new System.Windows.Forms.ToolStripMenuItem();
            this.itcSeleccionarTodo = new System.Windows.Forms.ToolStripMenuItem();
            this.mnEditor = new System.Windows.Forms.MenuStrip();
            this.archivoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.itGuardarComo = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator10 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripSeparator11 = new System.Windows.Forms.ToolStripSeparator();
            this.itSalir = new System.Windows.Forms.ToolStripMenuItem();
            this.ediciónToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator12 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripSeparator13 = new System.Windows.Forms.ToolStripSeparator();
            this.itBorrar = new System.Windows.Forms.ToolStripMenuItem();
            this.itSeleccionarTodo = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator14 = new System.Windows.Forms.ToolStripSeparator();
            this.itIra = new System.Windows.Forms.ToolStripMenuItem();
            this.verToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.itBarraEstandar = new System.Windows.Forms.ToolStripMenuItem();
            this.itBarraFormato = new System.Windows.Forms.ToolStripMenuItem();
            this.itBarraEstado = new System.Windows.Forms.ToolStripMenuItem();
            this.formatoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.itFuentes = new System.Windows.Forms.ToolStripMenuItem();
            this.itColorFondo = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator15 = new System.Windows.Forms.ToolStripSeparator();
            this.itMargenes = new System.Windows.Forms.ToolStripMenuItem();
            this.itJustificacion = new System.Windows.Forms.ToolStripMenuItem();
            this.itIzquierda = new System.Windows.Forms.ToolStripMenuItem();
            this.itCentrado = new System.Windows.Forms.ToolStripMenuItem();
            this.itDerecha = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator16 = new System.Windows.Forms.ToolStripSeparator();
            this.itVietas = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator17 = new System.Windows.Forms.ToolStripSeparator();
            this.itFormatoPagina = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator18 = new System.Windows.Forms.ToolStripSeparator();
            this.ayudaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.itAcercade = new System.Windows.Forms.ToolStripMenuItem();
            this.itAyuda = new System.Windows.Forms.ToolStripMenuItem();
            this.itGeneral = new System.Windows.Forms.ToolStripMenuItem();
            this.timeEditor = new System.Windows.Forms.Timer(this.components);
            this.dlgColores = new System.Windows.Forms.ColorDialog();
            this.dlgAbrir = new System.Windows.Forms.OpenFileDialog();
            this.dlgGuardar = new System.Windows.Forms.SaveFileDialog();
            this.dlgImprimir = new System.Windows.Forms.PrintDialog();
            this.prindocEditor = new System.Drawing.Printing.PrintDocument();
            this.dlgFuentes = new System.Windows.Forms.FontDialog();
            this.itcIra = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator21 = new System.Windows.Forms.ToolStripSeparator();
            this.totiEditor = new System.Windows.Forms.ToolTip(this.components);
            this.tsbNegrita = new System.Windows.Forms.ToolStripButton();
            this.tsbSubrayado = new System.Windows.Forms.ToolStripButton();
            this.tsbTachado = new System.Windows.Forms.ToolStripButton();
            this.tsbCursiva = new System.Windows.Forms.ToolStripButton();
            this.tsbIzquierda = new System.Windows.Forms.ToolStripButton();
            this.tsbCentrado = new System.Windows.Forms.ToolStripButton();
            this.tsbDerecha = new System.Windows.Forms.ToolStripButton();
            this.tsbPaleta = new System.Windows.Forms.ToolStripButton();
            this.tsbNuevo = new System.Windows.Forms.ToolStripButton();
            this.tsbAbrir = new System.Windows.Forms.ToolStripButton();
            this.tsbGuardar = new System.Windows.Forms.ToolStripButton();
            this.tsbImprimir = new System.Windows.Forms.ToolStripButton();
            this.tsbCortar = new System.Windows.Forms.ToolStripButton();
            this.tsbCopiar = new System.Windows.Forms.ToolStripButton();
            this.tsbPegar = new System.Windows.Forms.ToolStripButton();
            this.tsbDeshacer = new System.Windows.Forms.ToolStripButton();
            this.tsbRehacer = new System.Windows.Forms.ToolStripButton();
            this.tsbCopiarFormatos = new System.Windows.Forms.ToolStripButton();
            this.tsbQuitarFormatos = new System.Windows.Forms.ToolStripButton();
            this.itNuevo = new System.Windows.Forms.ToolStripMenuItem();
            this.itAbrir = new System.Windows.Forms.ToolStripMenuItem();
            this.itGuardar = new System.Windows.Forms.ToolStripMenuItem();
            this.itImprimir = new System.Windows.Forms.ToolStripMenuItem();
            this.itDeshacer = new System.Windows.Forms.ToolStripMenuItem();
            this.itRehacer = new System.Windows.Forms.ToolStripMenuItem();
            this.itCortar = new System.Windows.Forms.ToolStripMenuItem();
            this.itCopiar = new System.Windows.Forms.ToolStripMenuItem();
            this.itPegar = new System.Windows.Forms.ToolStripMenuItem();
            this.itQuitarFormatos = new System.Windows.Forms.ToolStripMenuItem();
            this.tsBarraEstandar.SuspendLayout();
            this.cmnBarras.SuspendLayout();
            this.tsBarraFormato.SuspendLayout();
            this.stEstadoEditor.SuspendLayout();
            this.cmnEditor.SuspendLayout();
            this.mnEditor.SuspendLayout();
            this.SuspendLayout();
            // 
            // tsBarraEstandar
            // 
            this.tsBarraEstandar.ContextMenuStrip = this.cmnBarras;
            this.tsBarraEstandar.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbNuevo,
            this.tsbAbrir,
            this.tsbGuardar,
            this.tsbImprimir,
            this.toolStripSeparator1,
            this.tsbCortar,
            this.tsbCopiar,
            this.tsbPegar,
            this.toolStripSeparator2,
            this.tsbDeshacer,
            this.tsbRehacer,
            this.toolStripSeparator3,
            this.tsbCopiarFormatos,
            this.toolStripSeparator4,
            this.tsbQuitarFormatos,
            this.toolStripSeparator5});
            this.tsBarraEstandar.Location = new System.Drawing.Point(0, 24);
            this.tsBarraEstandar.Name = "tsBarraEstandar";
            this.tsBarraEstandar.Size = new System.Drawing.Size(784, 25);
            this.tsBarraEstandar.TabIndex = 0;
            // 
            // cmnBarras
            // 
            this.cmnBarras.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.itcBarraEstandar,
            this.itcBarraFormato,
            this.itcBarraEstado});
            this.cmnBarras.Name = "cmnBarras";
            this.cmnBarras.Size = new System.Drawing.Size(156, 70);
            // 
            // itcBarraEstandar
            // 
            this.itcBarraEstandar.Checked = true;
            this.itcBarraEstandar.CheckState = System.Windows.Forms.CheckState.Checked;
            this.itcBarraEstandar.Name = "itcBarraEstandar";
            this.itcBarraEstandar.Size = new System.Drawing.Size(155, 22);
            this.itcBarraEstandar.Text = "Barra Estandar";
            this.itcBarraEstandar.Click += new System.EventHandler(this.itBarraEstandar_Click);
            // 
            // itcBarraFormato
            // 
            this.itcBarraFormato.Checked = true;
            this.itcBarraFormato.CheckState = System.Windows.Forms.CheckState.Checked;
            this.itcBarraFormato.Name = "itcBarraFormato";
            this.itcBarraFormato.Size = new System.Drawing.Size(155, 22);
            this.itcBarraFormato.Text = "Barra Formato";
            this.itcBarraFormato.Click += new System.EventHandler(this.itBarraFormato_Click);
            // 
            // itcBarraEstado
            // 
            this.itcBarraEstado.Checked = true;
            this.itcBarraEstado.CheckState = System.Windows.Forms.CheckState.Checked;
            this.itcBarraEstado.Name = "itcBarraEstado";
            this.itcBarraEstado.Size = new System.Drawing.Size(155, 22);
            this.itcBarraEstado.Text = "Barra de Estado";
            this.itcBarraEstado.Click += new System.EventHandler(this.itBarraEstado_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(6, 25);
            // 
            // tsBarraFormato
            // 
            this.tsBarraFormato.ContextMenuStrip = this.cmnBarras;
            this.tsBarraFormato.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbNegrita,
            this.tsbSubrayado,
            this.tsbTachado,
            this.tsbCursiva,
            this.toolStripSeparator6,
            this.tsbIzquierda,
            this.tsbCentrado,
            this.tsbDerecha,
            this.toolStripSeparator7,
            this.cbFuentes,
            this.toolStripSeparator8,
            this.cbTamanyo,
            this.toolStripSeparator9,
            this.tsbPaleta});
            this.tsBarraFormato.Location = new System.Drawing.Point(0, 49);
            this.tsBarraFormato.Name = "tsBarraFormato";
            this.tsBarraFormato.Size = new System.Drawing.Size(784, 25);
            this.tsBarraFormato.TabIndex = 1;
            // 
            // toolStripSeparator6
            // 
            this.toolStripSeparator6.Name = "toolStripSeparator6";
            this.toolStripSeparator6.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripSeparator7
            // 
            this.toolStripSeparator7.Name = "toolStripSeparator7";
            this.toolStripSeparator7.Size = new System.Drawing.Size(6, 25);
            // 
            // cbFuentes
            // 
            this.cbFuentes.AutoToolTip = true;
            this.cbFuentes.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbFuentes.Name = "cbFuentes";
            this.cbFuentes.Size = new System.Drawing.Size(121, 25);
            this.cbFuentes.ToolTipText = "Nombre del tipo de letra";
            this.cbFuentes.SelectedIndexChanged += new System.EventHandler(this.cbFuentes_SelectedIndexChanged);
            this.cbFuentes.MouseHover += new System.EventHandler(this.tsbNegrita_MouseHover);
            // 
            // toolStripSeparator8
            // 
            this.toolStripSeparator8.Name = "toolStripSeparator8";
            this.toolStripSeparator8.Size = new System.Drawing.Size(6, 25);
            // 
            // cbTamanyo
            // 
            this.cbTamanyo.AutoSize = false;
            this.cbTamanyo.DropDownWidth = 75;
            this.cbTamanyo.Items.AddRange(new object[] {
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20",
            "21",
            "22",
            "23",
            "24",
            "25",
            "26",
            "27",
            "28",
            "30",
            "32",
            "34",
            "36",
            "38",
            "40",
            "42",
            "44",
            "46",
            "50",
            "54",
            "58",
            "62",
            "66",
            "70",
            "78",
            "86",
            "94"});
            this.cbTamanyo.MaxLength = 3;
            this.cbTamanyo.Name = "cbTamanyo";
            this.cbTamanyo.Size = new System.Drawing.Size(50, 23);
            this.cbTamanyo.ToolTipText = "Tamaño de letra";
            this.cbTamanyo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cbTamanyo_KeyPress);
            this.cbTamanyo.MouseHover += new System.EventHandler(this.tsbNegrita_MouseHover);
            this.cbTamanyo.TextChanged += new System.EventHandler(this.cbTamanyo_TextChanged);
            // 
            // toolStripSeparator9
            // 
            this.toolStripSeparator9.Name = "toolStripSeparator9";
            this.toolStripSeparator9.Size = new System.Drawing.Size(6, 25);
            // 
            // stEstadoEditor
            // 
            this.stEstadoEditor.ContextMenuStrip = this.cmnBarras;
            this.stEstadoEditor.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.sl1,
            this.sl2,
            this.sl3,
            this.sl4,
            this.sl5});
            this.stEstadoEditor.Location = new System.Drawing.Point(0, 417);
            this.stEstadoEditor.Name = "stEstadoEditor";
            this.stEstadoEditor.Size = new System.Drawing.Size(784, 24);
            this.stEstadoEditor.TabIndex = 2;
            this.stEstadoEditor.Text = "statusStrip1";
            this.totiEditor.SetToolTip(this.stEstadoEditor, "Barra de estado.");
            // 
            // sl1
            // 
            this.sl1.AutoSize = false;
            this.sl1.BorderSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.Left;
            this.sl1.BorderStyle = System.Windows.Forms.Border3DStyle.RaisedOuter;
            this.sl1.Name = "sl1";
            this.sl1.Size = new System.Drawing.Size(450, 19);
            this.sl1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.sl1.ToolTipText = "Estado de los componentes.";
            // 
            // sl2
            // 
            this.sl2.AutoSize = false;
            this.sl2.BorderSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.Left;
            this.sl2.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenOuter;
            this.sl2.Name = "sl2";
            this.sl2.Size = new System.Drawing.Size(100, 19);
            // 
            // sl3
            // 
            this.sl3.AutoSize = false;
            this.sl3.BorderSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.Left;
            this.sl3.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenOuter;
            this.sl3.Name = "sl3";
            this.sl3.Size = new System.Drawing.Size(60, 19);
            // 
            // sl4
            // 
            this.sl4.AutoSize = false;
            this.sl4.BorderSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.Left;
            this.sl4.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenOuter;
            this.sl4.Name = "sl4";
            this.sl4.Size = new System.Drawing.Size(70, 19);
            // 
            // sl5
            // 
            this.sl5.AutoSize = false;
            this.sl5.BorderSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.Left;
            this.sl5.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenOuter;
            this.sl5.Name = "sl5";
            this.sl5.Size = new System.Drawing.Size(90, 19);
            this.sl5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // rtbEditor
            // 
            this.rtbEditor.ContextMenuStrip = this.cmnEditor;
            this.rtbEditor.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rtbEditor.Location = new System.Drawing.Point(0, 74);
            this.rtbEditor.Name = "rtbEditor";
            this.rtbEditor.Size = new System.Drawing.Size(784, 343);
            this.rtbEditor.TabIndex = 3;
            this.rtbEditor.Text = "";
            this.rtbEditor.SelectionChanged += new System.EventHandler(this.rtbEditor_SelectionChanged);
            this.rtbEditor.MouseDown += new System.Windows.Forms.MouseEventHandler(this.rtbEditor_MouseDown);
            // 
            // cmnEditor
            // 
            this.cmnEditor.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.itcDeshacer,
            this.itcRehacer,
            this.toolStripSeparator19,
            this.itcCortar,
            this.itcCopiar,
            this.itcPegar,
            this.toolStripSeparator20,
            this.itcBorrar,
            this.itcSeleccionarTodo,
            this.toolStripSeparator21,
            this.itcIra});
            this.cmnEditor.Name = "cmnEditor";
            this.cmnEditor.Size = new System.Drawing.Size(164, 198);
            // 
            // itcDeshacer
            // 
            this.itcDeshacer.Name = "itcDeshacer";
            this.itcDeshacer.Size = new System.Drawing.Size(163, 22);
            this.itcDeshacer.Text = "Deshacer";
            this.itcDeshacer.Click += new System.EventHandler(this.itDeshacer_Click);
            // 
            // itcRehacer
            // 
            this.itcRehacer.Name = "itcRehacer";
            this.itcRehacer.Size = new System.Drawing.Size(163, 22);
            this.itcRehacer.Text = "Rehacer";
            this.itcRehacer.Click += new System.EventHandler(this.itRehacer_Click);
            // 
            // toolStripSeparator19
            // 
            this.toolStripSeparator19.Name = "toolStripSeparator19";
            this.toolStripSeparator19.Size = new System.Drawing.Size(160, 6);
            // 
            // itcCortar
            // 
            this.itcCortar.Name = "itcCortar";
            this.itcCortar.Size = new System.Drawing.Size(163, 22);
            this.itcCortar.Text = "Cortar";
            this.itcCortar.Click += new System.EventHandler(this.itCortar_Click);
            // 
            // itcCopiar
            // 
            this.itcCopiar.Name = "itcCopiar";
            this.itcCopiar.Size = new System.Drawing.Size(163, 22);
            this.itcCopiar.Text = "Copiar";
            this.itcCopiar.Click += new System.EventHandler(this.itCopiar_Click);
            // 
            // itcPegar
            // 
            this.itcPegar.Name = "itcPegar";
            this.itcPegar.Size = new System.Drawing.Size(163, 22);
            this.itcPegar.Text = "Pegar";
            this.itcPegar.Click += new System.EventHandler(this.itPegar_Click);
            // 
            // toolStripSeparator20
            // 
            this.toolStripSeparator20.Name = "toolStripSeparator20";
            this.toolStripSeparator20.Size = new System.Drawing.Size(160, 6);
            // 
            // itcBorrar
            // 
            this.itcBorrar.Name = "itcBorrar";
            this.itcBorrar.Size = new System.Drawing.Size(163, 22);
            this.itcBorrar.Text = "Borrar";
            this.itcBorrar.Click += new System.EventHandler(this.itBorrar_Click);
            // 
            // itcSeleccionarTodo
            // 
            this.itcSeleccionarTodo.Name = "itcSeleccionarTodo";
            this.itcSeleccionarTodo.Size = new System.Drawing.Size(163, 22);
            this.itcSeleccionarTodo.Text = "Seleccionar Todo";
            this.itcSeleccionarTodo.Click += new System.EventHandler(this.itSeleccionarTodo_Click);
            // 
            // mnEditor
            // 
            this.mnEditor.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.archivoToolStripMenuItem,
            this.ediciónToolStripMenuItem,
            this.verToolStripMenuItem,
            this.formatoToolStripMenuItem,
            this.ayudaToolStripMenuItem});
            this.mnEditor.Location = new System.Drawing.Point(0, 0);
            this.mnEditor.Name = "mnEditor";
            this.mnEditor.Size = new System.Drawing.Size(784, 24);
            this.mnEditor.TabIndex = 4;
            this.mnEditor.Text = "menuStrip1";
            // 
            // archivoToolStripMenuItem
            // 
            this.archivoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.itNuevo,
            this.itAbrir,
            this.itGuardar,
            this.itGuardarComo,
            this.toolStripSeparator10,
            this.itImprimir,
            this.toolStripSeparator11,
            this.itSalir});
            this.archivoToolStripMenuItem.Name = "archivoToolStripMenuItem";
            this.archivoToolStripMenuItem.Size = new System.Drawing.Size(60, 20);
            this.archivoToolStripMenuItem.Text = "A&rchivo";
            // 
            // itGuardarComo
            // 
            this.itGuardarComo.Name = "itGuardarComo";
            this.itGuardarComo.Size = new System.Drawing.Size(158, 22);
            this.itGuardarComo.Text = "G&uardar Como";
            this.itGuardarComo.Click += new System.EventHandler(this.itGuardarComo_Click);
            // 
            // toolStripSeparator10
            // 
            this.toolStripSeparator10.Name = "toolStripSeparator10";
            this.toolStripSeparator10.Size = new System.Drawing.Size(155, 6);
            // 
            // toolStripSeparator11
            // 
            this.toolStripSeparator11.Name = "toolStripSeparator11";
            this.toolStripSeparator11.Size = new System.Drawing.Size(155, 6);
            // 
            // itSalir
            // 
            this.itSalir.Name = "itSalir";
            this.itSalir.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.S)));
            this.itSalir.Size = new System.Drawing.Size(158, 22);
            this.itSalir.Text = "&Salir";
            this.itSalir.Click += new System.EventHandler(this.itSalir_Click);
            // 
            // ediciónToolStripMenuItem
            // 
            this.ediciónToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.itDeshacer,
            this.itRehacer,
            this.toolStripSeparator12,
            this.itCortar,
            this.itCopiar,
            this.itPegar,
            this.toolStripSeparator13,
            this.itBorrar,
            this.itSeleccionarTodo,
            this.toolStripSeparator14,
            this.itIra});
            this.ediciónToolStripMenuItem.Name = "ediciónToolStripMenuItem";
            this.ediciónToolStripMenuItem.Size = new System.Drawing.Size(58, 20);
            this.ediciónToolStripMenuItem.Text = "Edición";
            // 
            // toolStripSeparator12
            // 
            this.toolStripSeparator12.Name = "toolStripSeparator12";
            this.toolStripSeparator12.Size = new System.Drawing.Size(177, 6);
            // 
            // toolStripSeparator13
            // 
            this.toolStripSeparator13.Name = "toolStripSeparator13";
            this.toolStripSeparator13.Size = new System.Drawing.Size(177, 6);
            // 
            // itBorrar
            // 
            this.itBorrar.Name = "itBorrar";
            this.itBorrar.ShortcutKeys = System.Windows.Forms.Keys.Delete;
            this.itBorrar.Size = new System.Drawing.Size(180, 22);
            this.itBorrar.Text = "Borrar";
            this.itBorrar.Click += new System.EventHandler(this.itBorrar_Click);
            // 
            // itSeleccionarTodo
            // 
            this.itSeleccionarTodo.Name = "itSeleccionarTodo";
            this.itSeleccionarTodo.Size = new System.Drawing.Size(180, 22);
            this.itSeleccionarTodo.Text = "Seleccionar Todo";
            this.itSeleccionarTodo.Click += new System.EventHandler(this.itSeleccionarTodo_Click);
            // 
            // toolStripSeparator14
            // 
            this.toolStripSeparator14.Name = "toolStripSeparator14";
            this.toolStripSeparator14.Size = new System.Drawing.Size(177, 6);
            // 
            // itIra
            // 
            this.itIra.Name = "itIra";
            this.itIra.Size = new System.Drawing.Size(180, 22);
            this.itIra.Text = "Ir a Línea";
            this.itIra.Click += new System.EventHandler(this.itIra_Click);
            // 
            // verToolStripMenuItem
            // 
            this.verToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.itBarraEstandar,
            this.itBarraFormato,
            this.itBarraEstado});
            this.verToolStripMenuItem.Name = "verToolStripMenuItem";
            this.verToolStripMenuItem.Size = new System.Drawing.Size(35, 20);
            this.verToolStripMenuItem.Text = "&Ver";
            // 
            // itBarraEstandar
            // 
            this.itBarraEstandar.Checked = true;
            this.itBarraEstandar.CheckState = System.Windows.Forms.CheckState.Checked;
            this.itBarraEstandar.Name = "itBarraEstandar";
            this.itBarraEstandar.Size = new System.Drawing.Size(237, 22);
            this.itBarraEstandar.Text = "Barra de herramientas &Estándar";
            this.itBarraEstandar.Click += new System.EventHandler(this.itBarraEstandar_Click);
            // 
            // itBarraFormato
            // 
            this.itBarraFormato.Checked = true;
            this.itBarraFormato.CheckState = System.Windows.Forms.CheckState.Checked;
            this.itBarraFormato.Name = "itBarraFormato";
            this.itBarraFormato.Size = new System.Drawing.Size(237, 22);
            this.itBarraFormato.Text = "Barra de herramientas &Formato";
            this.itBarraFormato.Click += new System.EventHandler(this.itBarraFormato_Click);
            // 
            // itBarraEstado
            // 
            this.itBarraEstado.Checked = true;
            this.itBarraEstado.CheckState = System.Windows.Forms.CheckState.Checked;
            this.itBarraEstado.Name = "itBarraEstado";
            this.itBarraEstado.Size = new System.Drawing.Size(237, 22);
            this.itBarraEstado.Text = "Barra de E&stado";
            this.itBarraEstado.Click += new System.EventHandler(this.itBarraEstado_Click);
            // 
            // formatoToolStripMenuItem
            // 
            this.formatoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.itFuentes,
            this.itColorFondo,
            this.toolStripSeparator15,
            this.itMargenes,
            this.itJustificacion,
            this.toolStripSeparator16,
            this.itVietas,
            this.toolStripSeparator17,
            this.itFormatoPagina,
            this.toolStripSeparator18,
            this.itQuitarFormatos});
            this.formatoToolStripMenuItem.Name = "formatoToolStripMenuItem";
            this.formatoToolStripMenuItem.Size = new System.Drawing.Size(64, 20);
            this.formatoToolStripMenuItem.Text = "&Formato";
            // 
            // itFuentes
            // 
            this.itFuentes.Name = "itFuentes";
            this.itFuentes.Size = new System.Drawing.Size(221, 22);
            this.itFuentes.Text = "F&uentes";
            this.itFuentes.Click += new System.EventHandler(this.itFuentes_Click);
            // 
            // itColorFondo
            // 
            this.itColorFondo.Name = "itColorFondo";
            this.itColorFondo.Size = new System.Drawing.Size(221, 22);
            this.itColorFondo.Text = "&Color de Fondo";
            this.itColorFondo.Click += new System.EventHandler(this.itColorFondo_Click);
            // 
            // toolStripSeparator15
            // 
            this.toolStripSeparator15.Name = "toolStripSeparator15";
            this.toolStripSeparator15.Size = new System.Drawing.Size(218, 6);
            // 
            // itMargenes
            // 
            this.itMargenes.Name = "itMargenes";
            this.itMargenes.Size = new System.Drawing.Size(221, 22);
            this.itMargenes.Text = "&Márgenes";
            this.itMargenes.Click += new System.EventHandler(this.itMargenes_Click);
            // 
            // itJustificacion
            // 
            this.itJustificacion.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.itIzquierda,
            this.itCentrado,
            this.itDerecha});
            this.itJustificacion.Name = "itJustificacion";
            this.itJustificacion.Size = new System.Drawing.Size(221, 22);
            this.itJustificacion.Text = "&Justificación";
            // 
            // itIzquierda
            // 
            this.itIzquierda.Checked = true;
            this.itIzquierda.CheckState = System.Windows.Forms.CheckState.Checked;
            this.itIzquierda.Name = "itIzquierda";
            this.itIzquierda.Size = new System.Drawing.Size(180, 22);
            this.itIzquierda.Text = "&Izquierda";
            this.itIzquierda.Click += new System.EventHandler(this.tsbIzquierda_Click);
            // 
            // itCentrado
            // 
            this.itCentrado.Name = "itCentrado";
            this.itCentrado.Size = new System.Drawing.Size(180, 22);
            this.itCentrado.Text = "C&entrado";
            this.itCentrado.Click += new System.EventHandler(this.tsbCentrado_Click);
            // 
            // itDerecha
            // 
            this.itDerecha.Name = "itDerecha";
            this.itDerecha.Size = new System.Drawing.Size(180, 22);
            this.itDerecha.Text = "&Derecha";
            this.itDerecha.Click += new System.EventHandler(this.tsbDerecha_Click);
            // 
            // toolStripSeparator16
            // 
            this.toolStripSeparator16.Name = "toolStripSeparator16";
            this.toolStripSeparator16.Size = new System.Drawing.Size(218, 6);
            // 
            // itVietas
            // 
            this.itVietas.Name = "itVietas";
            this.itVietas.Size = new System.Drawing.Size(221, 22);
            this.itVietas.Text = "&Viñetas";
            this.itVietas.Click += new System.EventHandler(this.itVietas_Click);
            // 
            // toolStripSeparator17
            // 
            this.toolStripSeparator17.Name = "toolStripSeparator17";
            this.toolStripSeparator17.Size = new System.Drawing.Size(218, 6);
            // 
            // itFormatoPagina
            // 
            this.itFormatoPagina.Name = "itFormatoPagina";
            this.itFormatoPagina.Size = new System.Drawing.Size(221, 22);
            this.itFormatoPagina.Text = "F&ormato de página";
            this.itFormatoPagina.Click += new System.EventHandler(this.itFormatoPagina_Click);
            // 
            // toolStripSeparator18
            // 
            this.toolStripSeparator18.Name = "toolStripSeparator18";
            this.toolStripSeparator18.Size = new System.Drawing.Size(218, 6);
            // 
            // ayudaToolStripMenuItem
            // 
            this.ayudaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.itAcercade,
            this.itAyuda,
            this.itGeneral});
            this.ayudaToolStripMenuItem.Name = "ayudaToolStripMenuItem";
            this.ayudaToolStripMenuItem.Size = new System.Drawing.Size(53, 20);
            this.ayudaToolStripMenuItem.Text = "A&yuda";
            // 
            // itAcercade
            // 
            this.itAcercade.Name = "itAcercade";
            this.itAcercade.Size = new System.Drawing.Size(180, 22);
            this.itAcercade.Text = "&Acerca de";
            this.itAcercade.Click += new System.EventHandler(this.itAcercade_Click);
            // 
            // itAyuda
            // 
            this.itAyuda.Name = "itAyuda";
            this.itAyuda.Size = new System.Drawing.Size(180, 22);
            this.itAyuda.Text = "&Indice Ayuda";
            // 
            // itGeneral
            // 
            this.itGeneral.Name = "itGeneral";
            this.itGeneral.Size = new System.Drawing.Size(180, 22);
            this.itGeneral.Text = "Ay&uda General";
            // 
            // timeEditor
            // 
            this.timeEditor.Enabled = true;
            this.timeEditor.Interval = 1000;
            this.timeEditor.Tick += new System.EventHandler(this.timeEditor_Tick);
            // 
            // dlgColores
            // 
            this.dlgColores.AnyColor = true;
            // 
            // dlgAbrir
            // 
            this.dlgAbrir.AutoUpgradeEnabled = false;
            this.dlgAbrir.DefaultExt = "rtf";
            this.dlgAbrir.Filter = "Archivos de texto (*.txt)|*.txt|Archivo Enriquecido (*.rtf)|*.rtf|Todos los archi" +
    "vos (*.*)|*.*";
            this.dlgAbrir.InitialDirectory = ".\\archivos";
            this.dlgAbrir.Title = "Abrir documentos";
            // 
            // dlgGuardar
            // 
            this.dlgGuardar.AutoUpgradeEnabled = false;
            this.dlgGuardar.DefaultExt = "rtf";
            this.dlgGuardar.Filter = "Archivo de Texto (.txt)|*.txt|Archivo Enriquecido(.rtf)|*.rtf";
            this.dlgGuardar.InitialDirectory = ".\\archivos";
            this.dlgGuardar.Title = "Guardar Documento";
            // 
            // dlgImprimir
            // 
            this.dlgImprimir.AllowPrintToFile = false;
            this.dlgImprimir.AllowSomePages = true;
            this.dlgImprimir.Document = this.prindocEditor;
            this.dlgImprimir.UseEXDialog = true;
            // 
            // prindocEditor
            // 
            this.prindocEditor.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.prindocEditor_PrintPage);
            // 
            // dlgFuentes
            // 
            this.dlgFuentes.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dlgFuentes.ShowColor = true;
            // 
            // itcIra
            // 
            this.itcIra.Name = "itcIra";
            this.itcIra.Size = new System.Drawing.Size(163, 22);
            this.itcIra.Text = "Ir a Línea";
            this.itcIra.Click += new System.EventHandler(this.itIra_Click);
            // 
            // toolStripSeparator21
            // 
            this.toolStripSeparator21.Name = "toolStripSeparator21";
            this.toolStripSeparator21.Size = new System.Drawing.Size(160, 6);
            // 
            // totiEditor
            // 
            this.totiEditor.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Info;
            this.totiEditor.ToolTipTitle = "Editor:";
            // 
            // tsbNegrita
            // 
            this.tsbNegrita.CheckOnClick = true;
            this.tsbNegrita.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbNegrita.Image = global::Editor.Properties.Resources.negrita;
            this.tsbNegrita.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbNegrita.Name = "tsbNegrita";
            this.tsbNegrita.Size = new System.Drawing.Size(23, 22);
            this.tsbNegrita.Text = "Negrita";
            this.tsbNegrita.ToolTipText = "Negrita";
            this.tsbNegrita.Click += new System.EventHandler(this.tsbNegrita_Click);
            this.tsbNegrita.MouseHover += new System.EventHandler(this.tsbNegrita_MouseHover);
            // 
            // tsbSubrayado
            // 
            this.tsbSubrayado.CheckOnClick = true;
            this.tsbSubrayado.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbSubrayado.Image = global::Editor.Properties.Resources.subrayado;
            this.tsbSubrayado.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbSubrayado.Name = "tsbSubrayado";
            this.tsbSubrayado.Size = new System.Drawing.Size(23, 22);
            this.tsbSubrayado.Text = "Subrayado";
            this.tsbSubrayado.ToolTipText = "Subrayado";
            this.tsbSubrayado.Click += new System.EventHandler(this.tsbNegrita_Click);
            this.tsbSubrayado.MouseHover += new System.EventHandler(this.tsbNegrita_MouseHover);
            // 
            // tsbTachado
            // 
            this.tsbTachado.CheckOnClick = true;
            this.tsbTachado.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbTachado.Image = global::Editor.Properties.Resources.tachado;
            this.tsbTachado.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbTachado.Name = "tsbTachado";
            this.tsbTachado.Size = new System.Drawing.Size(23, 22);
            this.tsbTachado.Text = "Tachado";
            this.tsbTachado.Click += new System.EventHandler(this.tsbNegrita_Click);
            this.tsbTachado.MouseHover += new System.EventHandler(this.tsbNegrita_MouseHover);
            // 
            // tsbCursiva
            // 
            this.tsbCursiva.CheckOnClick = true;
            this.tsbCursiva.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbCursiva.Image = global::Editor.Properties.Resources.cursiva;
            this.tsbCursiva.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbCursiva.Name = "tsbCursiva";
            this.tsbCursiva.Size = new System.Drawing.Size(23, 22);
            this.tsbCursiva.Text = "Cursiva";
            this.tsbCursiva.Click += new System.EventHandler(this.tsbNegrita_Click);
            this.tsbCursiva.MouseHover += new System.EventHandler(this.tsbNegrita_MouseHover);
            // 
            // tsbIzquierda
            // 
            this.tsbIzquierda.Checked = true;
            this.tsbIzquierda.CheckState = System.Windows.Forms.CheckState.Checked;
            this.tsbIzquierda.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbIzquierda.Image = global::Editor.Properties.Resources.ALINEAizq;
            this.tsbIzquierda.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbIzquierda.Name = "tsbIzquierda";
            this.tsbIzquierda.Size = new System.Drawing.Size(23, 22);
            this.tsbIzquierda.Text = "Alinea izquierda";
            this.tsbIzquierda.ToolTipText = "Alinear a la izquierda";
            this.tsbIzquierda.Click += new System.EventHandler(this.tsbIzquierda_Click);
            this.tsbIzquierda.MouseHover += new System.EventHandler(this.tsbNegrita_MouseHover);
            // 
            // tsbCentrado
            // 
            this.tsbCentrado.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbCentrado.Image = global::Editor.Properties.Resources.ALINEAcentro;
            this.tsbCentrado.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbCentrado.Name = "tsbCentrado";
            this.tsbCentrado.Size = new System.Drawing.Size(23, 22);
            this.tsbCentrado.Text = "Alinea Centro";
            this.tsbCentrado.ToolTipText = "Alinear al centro";
            this.tsbCentrado.Click += new System.EventHandler(this.tsbCentrado_Click);
            this.tsbCentrado.MouseHover += new System.EventHandler(this.tsbNegrita_MouseHover);
            // 
            // tsbDerecha
            // 
            this.tsbDerecha.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbDerecha.Image = global::Editor.Properties.Resources.ALINEAder;
            this.tsbDerecha.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbDerecha.Name = "tsbDerecha";
            this.tsbDerecha.Size = new System.Drawing.Size(23, 22);
            this.tsbDerecha.Text = "toolStripButton7";
            this.tsbDerecha.ToolTipText = "Alinear a la derecha";
            this.tsbDerecha.Click += new System.EventHandler(this.tsbDerecha_Click);
            this.tsbDerecha.MouseHover += new System.EventHandler(this.tsbNegrita_MouseHover);
            // 
            // tsbPaleta
            // 
            this.tsbPaleta.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbPaleta.Image = global::Editor.Properties.Resources.PALETA;
            this.tsbPaleta.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbPaleta.Name = "tsbPaleta";
            this.tsbPaleta.Size = new System.Drawing.Size(23, 22);
            this.tsbPaleta.Text = "Paleta";
            this.tsbPaleta.ToolTipText = "Paleta de colores";
            this.tsbPaleta.Click += new System.EventHandler(this.tsbPaleta_Click);
            this.tsbPaleta.MouseHover += new System.EventHandler(this.tsbNegrita_MouseHover);
            // 
            // tsbNuevo
            // 
            this.tsbNuevo.BackColor = System.Drawing.SystemColors.Control;
            this.tsbNuevo.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbNuevo.Image = global::Editor.Properties.Resources.NUEVO;
            this.tsbNuevo.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbNuevo.Name = "tsbNuevo";
            this.tsbNuevo.Size = new System.Drawing.Size(23, 22);
            this.tsbNuevo.Text = "Nuevo";
            this.tsbNuevo.ToolTipText = "Nuevo (Ctrl+U)";
            this.tsbNuevo.Click += new System.EventHandler(this.itNuevo_Click);
            this.tsbNuevo.MouseHover += new System.EventHandler(this.tsbNegrita_MouseHover);
            // 
            // tsbAbrir
            // 
            this.tsbAbrir.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbAbrir.Image = global::Editor.Properties.Resources.ABRIR;
            this.tsbAbrir.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbAbrir.Name = "tsbAbrir";
            this.tsbAbrir.Size = new System.Drawing.Size(23, 22);
            this.tsbAbrir.Text = "Abrir";
            this.tsbAbrir.ToolTipText = "Abrir (Ctrl+A)";
            this.tsbAbrir.Click += new System.EventHandler(this.itAbrir_Click);
            this.tsbAbrir.MouseHover += new System.EventHandler(this.tsbNegrita_MouseHover);
            // 
            // tsbGuardar
            // 
            this.tsbGuardar.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbGuardar.Image = global::Editor.Properties.Resources.guardar;
            this.tsbGuardar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbGuardar.Name = "tsbGuardar";
            this.tsbGuardar.Size = new System.Drawing.Size(23, 22);
            this.tsbGuardar.Text = "Guardar";
            this.tsbGuardar.ToolTipText = "Guardar (Ctrl+G)";
            this.tsbGuardar.Click += new System.EventHandler(this.itGuardar_Click);
            this.tsbGuardar.MouseHover += new System.EventHandler(this.tsbNegrita_MouseHover);
            // 
            // tsbImprimir
            // 
            this.tsbImprimir.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbImprimir.Image = global::Editor.Properties.Resources.imprimir;
            this.tsbImprimir.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbImprimir.Name = "tsbImprimir";
            this.tsbImprimir.Size = new System.Drawing.Size(23, 22);
            this.tsbImprimir.Text = "Imprimir";
            this.tsbImprimir.ToolTipText = "Imprimir el documento";
            this.tsbImprimir.Click += new System.EventHandler(this.itImprimir_Click);
            this.tsbImprimir.MouseHover += new System.EventHandler(this.tsbNegrita_MouseHover);
            // 
            // tsbCortar
            // 
            this.tsbCortar.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbCortar.Image = global::Editor.Properties.Resources.CORTAR;
            this.tsbCortar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbCortar.Name = "tsbCortar";
            this.tsbCortar.Size = new System.Drawing.Size(23, 22);
            this.tsbCortar.Text = "Cortar";
            this.tsbCortar.ToolTipText = "Cortar (Ctrl+X)";
            this.tsbCortar.Click += new System.EventHandler(this.itCortar_Click);
            this.tsbCortar.MouseHover += new System.EventHandler(this.tsbNegrita_MouseHover);
            // 
            // tsbCopiar
            // 
            this.tsbCopiar.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbCopiar.Image = global::Editor.Properties.Resources.COPIA;
            this.tsbCopiar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbCopiar.Name = "tsbCopiar";
            this.tsbCopiar.Size = new System.Drawing.Size(23, 22);
            this.tsbCopiar.Text = "Copiar";
            this.tsbCopiar.ToolTipText = "Copiar (Ctrl+C)";
            this.tsbCopiar.Click += new System.EventHandler(this.itCopiar_Click);
            this.tsbCopiar.MouseHover += new System.EventHandler(this.tsbNegrita_MouseHover);
            // 
            // tsbPegar
            // 
            this.tsbPegar.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbPegar.Image = global::Editor.Properties.Resources.PEGAR;
            this.tsbPegar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbPegar.Name = "tsbPegar";
            this.tsbPegar.Size = new System.Drawing.Size(23, 22);
            this.tsbPegar.Text = "Pegar";
            this.tsbPegar.ToolTipText = "Pegar (Ctrl+V)";
            this.tsbPegar.Click += new System.EventHandler(this.itPegar_Click);
            this.tsbPegar.MouseHover += new System.EventHandler(this.tsbNegrita_MouseHover);
            // 
            // tsbDeshacer
            // 
            this.tsbDeshacer.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbDeshacer.Image = global::Editor.Properties.Resources.DESHACER;
            this.tsbDeshacer.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbDeshacer.Name = "tsbDeshacer";
            this.tsbDeshacer.Size = new System.Drawing.Size(23, 22);
            this.tsbDeshacer.Text = "Deshacer";
            this.tsbDeshacer.ToolTipText = "Deshacer (Ctrl+Z)";
            this.tsbDeshacer.Click += new System.EventHandler(this.itDeshacer_Click);
            this.tsbDeshacer.MouseHover += new System.EventHandler(this.tsbNegrita_MouseHover);
            // 
            // tsbRehacer
            // 
            this.tsbRehacer.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbRehacer.Image = global::Editor.Properties.Resources.rehacer;
            this.tsbRehacer.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbRehacer.Name = "tsbRehacer";
            this.tsbRehacer.Size = new System.Drawing.Size(23, 22);
            this.tsbRehacer.Text = "Rehacer";
            this.tsbRehacer.ToolTipText = "Rehacer (Ctrl+Y)";
            this.tsbRehacer.Click += new System.EventHandler(this.itRehacer_Click);
            this.tsbRehacer.MouseHover += new System.EventHandler(this.tsbNegrita_MouseHover);
            // 
            // tsbCopiarFormatos
            // 
            this.tsbCopiarFormatos.CheckOnClick = true;
            this.tsbCopiarFormatos.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbCopiarFormatos.Image = global::Editor.Properties.Resources.CopiarFormatos;
            this.tsbCopiarFormatos.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbCopiarFormatos.Name = "tsbCopiarFormatos";
            this.tsbCopiarFormatos.Size = new System.Drawing.Size(23, 22);
            this.tsbCopiarFormatos.Text = "Copiar Formatos";
            this.tsbCopiarFormatos.Click += new System.EventHandler(this.tsbCopiarFormatos_Click);
            this.tsbCopiarFormatos.MouseHover += new System.EventHandler(this.tsbNegrita_MouseHover);
            // 
            // tsbQuitarFormatos
            // 
            this.tsbQuitarFormatos.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbQuitarFormatos.Image = global::Editor.Properties.Resources.QuitarFormatos;
            this.tsbQuitarFormatos.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbQuitarFormatos.Name = "tsbQuitarFormatos";
            this.tsbQuitarFormatos.Size = new System.Drawing.Size(23, 22);
            this.tsbQuitarFormatos.Text = "Quitar Formatos";
            this.tsbQuitarFormatos.ToolTipText = "Quitar Formatos (Ctrl+Atrás)";
            this.tsbQuitarFormatos.Click += new System.EventHandler(this.itQuitarFormatos_Click);
            this.tsbQuitarFormatos.MouseHover += new System.EventHandler(this.tsbNegrita_MouseHover);
            // 
            // itNuevo
            // 
            this.itNuevo.Image = global::Editor.Properties.Resources.NUEVO;
            this.itNuevo.Name = "itNuevo";
            this.itNuevo.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.U)));
            this.itNuevo.Size = new System.Drawing.Size(158, 22);
            this.itNuevo.Text = "&Nuevo";
            this.itNuevo.Click += new System.EventHandler(this.itNuevo_Click);
            // 
            // itAbrir
            // 
            this.itAbrir.Image = global::Editor.Properties.Resources.ABRIR;
            this.itAbrir.Name = "itAbrir";
            this.itAbrir.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.A)));
            this.itAbrir.Size = new System.Drawing.Size(158, 22);
            this.itAbrir.Text = "&Abrir";
            this.itAbrir.Click += new System.EventHandler(this.itAbrir_Click);
            // 
            // itGuardar
            // 
            this.itGuardar.Image = global::Editor.Properties.Resources.GRABAR;
            this.itGuardar.Name = "itGuardar";
            this.itGuardar.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.G)));
            this.itGuardar.Size = new System.Drawing.Size(158, 22);
            this.itGuardar.Text = "&Guardar";
            this.itGuardar.Click += new System.EventHandler(this.itGuardar_Click);
            // 
            // itImprimir
            // 
            this.itImprimir.Image = global::Editor.Properties.Resources.imprimir;
            this.itImprimir.Name = "itImprimir";
            this.itImprimir.Size = new System.Drawing.Size(158, 22);
            this.itImprimir.Text = "&Imprimir";
            this.itImprimir.Click += new System.EventHandler(this.itImprimir_Click);
            // 
            // itDeshacer
            // 
            this.itDeshacer.Image = global::Editor.Properties.Resources.DESHACER;
            this.itDeshacer.Name = "itDeshacer";
            this.itDeshacer.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Z)));
            this.itDeshacer.Size = new System.Drawing.Size(180, 22);
            this.itDeshacer.Text = "Deshacer";
            this.itDeshacer.Click += new System.EventHandler(this.itDeshacer_Click);
            // 
            // itRehacer
            // 
            this.itRehacer.Image = global::Editor.Properties.Resources.rehacer;
            this.itRehacer.Name = "itRehacer";
            this.itRehacer.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Y)));
            this.itRehacer.Size = new System.Drawing.Size(180, 22);
            this.itRehacer.Text = "Rehacer";
            this.itRehacer.Click += new System.EventHandler(this.itRehacer_Click);
            // 
            // itCortar
            // 
            this.itCortar.Image = global::Editor.Properties.Resources.CORTAR;
            this.itCortar.Name = "itCortar";
            this.itCortar.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.X)));
            this.itCortar.Size = new System.Drawing.Size(180, 22);
            this.itCortar.Text = "Cortar";
            this.itCortar.Click += new System.EventHandler(this.itCortar_Click);
            // 
            // itCopiar
            // 
            this.itCopiar.Image = global::Editor.Properties.Resources.COPIA;
            this.itCopiar.Name = "itCopiar";
            this.itCopiar.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.C)));
            this.itCopiar.Size = new System.Drawing.Size(180, 22);
            this.itCopiar.Text = "Copiar";
            this.itCopiar.Click += new System.EventHandler(this.itCopiar_Click);
            // 
            // itPegar
            // 
            this.itPegar.Image = global::Editor.Properties.Resources.PEGAR;
            this.itPegar.Name = "itPegar";
            this.itPegar.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.V)));
            this.itPegar.Size = new System.Drawing.Size(180, 22);
            this.itPegar.Text = "Pegar";
            this.itPegar.Click += new System.EventHandler(this.itPegar_Click);
            // 
            // itQuitarFormatos
            // 
            this.itQuitarFormatos.Image = global::Editor.Properties.Resources.QuitarFormatos;
            this.itQuitarFormatos.Name = "itQuitarFormatos";
            this.itQuitarFormatos.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Back)));
            this.itQuitarFormatos.Size = new System.Drawing.Size(221, 22);
            this.itQuitarFormatos.Text = "Qui&tar Formatos";
            this.itQuitarFormatos.Click += new System.EventHandler(this.itQuitarFormatos_Click);
            // 
            // fmEditor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(784, 441);
            this.Controls.Add(this.rtbEditor);
            this.Controls.Add(this.stEstadoEditor);
            this.Controls.Add(this.tsBarraFormato);
            this.Controls.Add(this.tsBarraEstandar);
            this.Controls.Add(this.mnEditor);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.mnEditor;
            this.Name = "fmEditor";
            this.Text = "Editor";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.fmEditor_FormClosing);
            this.Load += new System.EventHandler(this.fmEditor_Load);
            this.Resize += new System.EventHandler(this.fmEditor_Resize);
            this.tsBarraEstandar.ResumeLayout(false);
            this.tsBarraEstandar.PerformLayout();
            this.cmnBarras.ResumeLayout(false);
            this.tsBarraFormato.ResumeLayout(false);
            this.tsBarraFormato.PerformLayout();
            this.stEstadoEditor.ResumeLayout(false);
            this.stEstadoEditor.PerformLayout();
            this.cmnEditor.ResumeLayout(false);
            this.mnEditor.ResumeLayout(false);
            this.mnEditor.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStrip tsBarraEstandar;
        private System.Windows.Forms.ToolStrip tsBarraFormato;
        private System.Windows.Forms.ToolStripButton tsbNuevo;
        private System.Windows.Forms.ToolStripButton tsbAbrir;
        private System.Windows.Forms.ToolStripButton tsbGuardar;
        private System.Windows.Forms.ToolStripButton tsbImprimir;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton tsbCortar;
        private System.Windows.Forms.ToolStripButton tsbCopiar;
        private System.Windows.Forms.ToolStripButton tsbPegar;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripButton tsbDeshacer;
        private System.Windows.Forms.ToolStripButton tsbRehacer;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripButton tsbCopiarFormatos;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripButton tsbQuitarFormatos;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripButton tsbNegrita;
        private System.Windows.Forms.ToolStripButton tsbSubrayado;
        private System.Windows.Forms.ToolStripButton tsbTachado;
        private System.Windows.Forms.ToolStripButton tsbCursiva;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
        private System.Windows.Forms.ToolStripButton tsbIzquierda;
        private System.Windows.Forms.ToolStripButton tsbCentrado;
        private System.Windows.Forms.ToolStripButton tsbDerecha;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator7;
        private System.Windows.Forms.ToolStripComboBox cbFuentes;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator8;
        private System.Windows.Forms.ToolStripComboBox cbTamanyo;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator9;
        private System.Windows.Forms.ToolStripButton tsbPaleta;
        private System.Windows.Forms.StatusStrip stEstadoEditor;
        private System.Windows.Forms.ToolStripStatusLabel sl1;
        private System.Windows.Forms.ToolStripStatusLabel sl2;
        private System.Windows.Forms.ToolStripStatusLabel sl3;
        private System.Windows.Forms.ToolStripStatusLabel sl4;
        private System.Windows.Forms.ToolStripStatusLabel sl5;
        private System.Windows.Forms.RichTextBox rtbEditor;
        private System.Windows.Forms.MenuStrip mnEditor;
        private System.Windows.Forms.ToolStripMenuItem archivoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem itNuevo;
        private System.Windows.Forms.ToolStripMenuItem itAbrir;
        private System.Windows.Forms.ToolStripMenuItem itGuardar;
        private System.Windows.Forms.ToolStripMenuItem itGuardarComo;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator10;
        private System.Windows.Forms.ToolStripMenuItem itImprimir;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator11;
        private System.Windows.Forms.ToolStripMenuItem itSalir;
        private System.Windows.Forms.ToolStripMenuItem ediciónToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem itDeshacer;
        private System.Windows.Forms.ToolStripMenuItem itRehacer;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator12;
        private System.Windows.Forms.ToolStripMenuItem itCortar;
        private System.Windows.Forms.ToolStripMenuItem itCopiar;
        private System.Windows.Forms.ToolStripMenuItem itPegar;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator13;
        private System.Windows.Forms.ToolStripMenuItem itBorrar;
        private System.Windows.Forms.ToolStripMenuItem itSeleccionarTodo;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator14;
        private System.Windows.Forms.ToolStripMenuItem itIra;
        private System.Windows.Forms.ToolStripMenuItem formatoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem itFuentes;
        private System.Windows.Forms.ToolStripMenuItem itColorFondo;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator15;
        private System.Windows.Forms.ToolStripMenuItem itMargenes;
        private System.Windows.Forms.ToolStripMenuItem itJustificacion;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator16;
        private System.Windows.Forms.ToolStripMenuItem itVietas;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator17;
        private System.Windows.Forms.ToolStripMenuItem itFormatoPagina;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator18;
        private System.Windows.Forms.ToolStripMenuItem itQuitarFormatos;
        private System.Windows.Forms.ToolStripMenuItem verToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem itBarraEstandar;
        private System.Windows.Forms.ToolStripMenuItem itBarraFormato;
        private System.Windows.Forms.ToolStripMenuItem itBarraEstado;
        private System.Windows.Forms.ToolStripMenuItem ayudaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem itAcercade;
        private System.Windows.Forms.ToolStripMenuItem itAyuda;
        private System.Windows.Forms.ToolStripMenuItem itGeneral;
        private System.Windows.Forms.ContextMenuStrip cmnBarras;
        private System.Windows.Forms.ToolStripMenuItem itcBarraEstandar;
        private System.Windows.Forms.ToolStripMenuItem itcBarraFormato;
        private System.Windows.Forms.ToolStripMenuItem itcBarraEstado;
        private System.Windows.Forms.ContextMenuStrip cmnEditor;
        private System.Windows.Forms.ToolStripMenuItem itcDeshacer;
        private System.Windows.Forms.ToolStripMenuItem itcRehacer;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator19;
        private System.Windows.Forms.ToolStripMenuItem itcCortar;
        private System.Windows.Forms.ToolStripMenuItem itcCopiar;
        private System.Windows.Forms.ToolStripMenuItem itcPegar;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator20;
        private System.Windows.Forms.ToolStripMenuItem itcBorrar;
        private System.Windows.Forms.ToolStripMenuItem itcSeleccionarTodo;
        private System.Windows.Forms.ToolStripMenuItem itIzquierda;
        private System.Windows.Forms.ToolStripMenuItem itCentrado;
        private System.Windows.Forms.ToolStripMenuItem itDerecha;
        private System.Windows.Forms.Timer timeEditor;
        private System.Windows.Forms.ColorDialog dlgColores;
        private System.Windows.Forms.OpenFileDialog dlgAbrir;
        private System.Windows.Forms.SaveFileDialog dlgGuardar;
        private System.Windows.Forms.PrintDialog dlgImprimir;
        private System.Drawing.Printing.PrintDocument prindocEditor;
        private System.Windows.Forms.FontDialog dlgFuentes;
        private System.Windows.Forms.ToolStripMenuItem itcIra;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator21;
        private System.Windows.Forms.ToolTip totiEditor;
    }
}

