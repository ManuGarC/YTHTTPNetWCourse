﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Editor
{
    public partial class fmMargenes : Form
    {
        public fmMargenes()
        {
            InitializeComponent();
        }

        private void cbIzquierdo_KeyPress(object sender, KeyPressEventArgs e)
        {
            switch (e.KeyChar)
            {
                //Solo aceptamos números.
                case '1':
                case '2':
                case '3':
                case '4':
                case '5':
                case '6':
                case '7':
                case '8':
                case '9':
                case '0':
                    break;
                case (char)8:  //Permitimos borrar con retroceso.
                    break;
                case (char)127: //Permitimos suprimir.
                    break;
                case (char)13:  //Permitimos Enter.
                    e.KeyChar = (char)0;
                    //Hacemos que actue como tabulador en los cb.
                    SendKeys.Send("{TAB}");
                    break;
                default:
                    e.KeyChar = (char)0; //anulamos la pulsación
                    break;
            }
        }

        private void cbIzquierdo_TextChanged(object sender, EventArgs e)
        {
            if (cbIzquierdo.Text == "")
            {
                cbIzquierdo.Text = "0";
            }
            if (cbDerecho.Text == "")
            {
                cbDerecho.Text = "0";
            }
        }
    }
}
