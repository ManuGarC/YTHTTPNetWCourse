﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Editor
{
    internal static class Program
    {
        /// <summary>
        /// Punto de entrada principal para la aplicación.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            fmPresentacion ventanapresentacion = new fmPresentacion();
            ventanapresentacion.ShowDialog();
            Application.Run(new fmEditor());//Inicia la aplicación no modificar
        }
    }
}
